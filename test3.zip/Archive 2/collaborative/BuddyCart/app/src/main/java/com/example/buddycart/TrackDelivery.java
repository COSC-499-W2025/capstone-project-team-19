// TrackDelivery.java
package com.example.buddycart;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.buddycart.model.Store;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class TrackDelivery extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Handler handler = new Handler();
    private ProgressBar loadingSpinner;
    private ImageView checkIcon;
    private TextView arrivingText;
    private int[] arrivalTimes = {20, 15, 10, 5};
    private int arrivalIndex = 0;
    private boolean notificationSent = false;

    public TrackDelivery() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.track_delivery, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        loadingSpinner = view.findViewById(R.id.loading_spinner);
        checkIcon = view.findViewById(R.id.check_icon);
        arrivingText = view.findViewById(R.id.arriving_text);
        Button messageButton = view.findViewById(R.id.btnMessage);

        // Initial text
        arrivingText.setText("Arriving in 20 minutes...");

        // Start countdown text changes
        handler.postDelayed(this::updateArrivalText, 3000);

        // Setup map
        SupportMapFragment mapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 100);
            }
        }

        messageButton.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new MessageDriver())
                    .addToBackStack(null)
                    .commit();
        });

        createNotificationChannel();
    }

    private void updateArrivalText() {
        if (arrivalIndex < arrivalTimes.length) {
            int minutes = arrivalTimes[arrivalIndex];
            arrivingText.setText("Arriving in " + minutes + " minutes...");

            if (minutes == 5 && !notificationSent) {
                sendArrivalNotification();
                notificationSent = true;
            }

            arrivalIndex++;
            handler.postDelayed(this::updateArrivalText, 3000);
        } else {
            arrivingText.setText("Steve is here");
        }
    }
    @SuppressLint("MissingPermission")
    private void sendArrivalNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(requireContext(), "delivery_channel")
                .setSmallIcon(R.drawable.ic_check)
                .setContentTitle("BuddyCart")
                .setContentText("Your order is arriving in 5 minutes")
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(requireContext());
        notificationManager.notify(1001, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Delivery Updates";
            String description = "Notifications for delivery status";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("delivery_channel", name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = requireContext().getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Example: get start location from Store.currentStore
        LatLng start;
        if (Store.currentStore != null) {
            String storeName = Store.currentStore.getName();
            switch (storeName) {
                case "Walmart":
                    start = new LatLng(49.89329296772238, -119.42451376277842);
                    break;
                case "IGA":
                    start = new LatLng(49.894633445085724, -119.39760260817191);
                    break;
                case "NoFrills":
                    start = new LatLng(49.89177800877002, -119.47464687194943);
                    break;
                case "Superstore":
                    start = new LatLng(49.88514598291859, -119.43280267691557);
                    break;
                default:
                    start = new LatLng(49.880498841812766, -119.44043970051366); // fallback
            }
        } else {
            start = new LatLng(49.880498841812766, -119.44043970051366); // default
        }

        LatLng end = new LatLng(49.94068067900804, -119.3936876117653);

        mMap.addPolyline(new PolylineOptions().add(start, end).width(5));

        LatLngBounds bounds = new LatLngBounds.Builder()
                .include(start)
                .include(end)
                .build();

        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100));
        mMap.getUiSettings().setZoomControlsEnabled(true);

        Marker movingMarker = mMap.addMarker(new MarkerOptions().position(start).title("Driver"));
        animateMarkerMovement(movingMarker, start, end, 15000); // 15 sec
    }

    private void animateMarkerMovement(Marker marker, LatLng start, LatLng end, long durationMs) {
        long startTime = System.currentTimeMillis();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = System.currentTimeMillis() - startTime;
                float t = Math.min(1f, (float) elapsed / durationMs);

                double lat = start.latitude + t * (end.latitude - start.latitude);
                double lng = start.longitude + t * (end.longitude - start.longitude);
                LatLng newPos = new LatLng(lat, lng);
                marker.setPosition(newPos);

                if (t < 1f) {
                    handler.postDelayed(this, 16);
                } else {
                    loadingSpinner.setVisibility(View.GONE);
                    checkIcon.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}


