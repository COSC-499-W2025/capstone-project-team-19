package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.buddycart.model.MyListData;
import com.example.buddycart.storage.MyListStorage;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MyListAddActivity extends AppCompatActivity {

    EditText titleInput, contentInput;
    Button saveListButton;
    ImageView backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inject mylist_2c.xml into the main container
        View contentView = getLayoutInflater().inflate(R.layout.mylist_2c, null);
        FrameLayout container = findViewById(R.id.fragment_container);
        container.removeAllViews();
        container.addView(contentView);

        // Find views from mylist_2c.xml
        titleInput = contentView.findViewById(R.id.listTitleInput);
        contentInput = contentView.findViewById(R.id.listContentInput);
        saveListButton = contentView.findViewById(R.id.saveListButton);
        backButton = contentView.findViewById(R.id.backButton);

        saveListButton.setOnClickListener(v -> {
            String title = titleInput.getText().toString().trim();
            String content = contentInput.getText().toString().trim();

            if (title.isEmpty() || content.isEmpty()) {
                Toast.makeText(this, "Please fill in both title and items", Toast.LENGTH_SHORT).show();
                return;
            }

            MyListData newList = new MyListData(title, content);
            MyListStorage.addList(newList);

            Toast.makeText(this, "List saved!", Toast.LENGTH_SHORT).show();
            finish(); // Return to previous screen
        });

        backButton.setOnClickListener(v -> finish());

        setupBottomNav();
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        bottomNav.setSelectedItemId(R.id.nav_list); // highlight current section

        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            Intent intent = new Intent(this, MainActivity.class);

            if (itemId == R.id.nav_home) {
                intent.putExtra("fragmentToShow", "home");
            } else if (itemId == R.id.nav_track) {
                intent.putExtra("fragmentToShow", "track");
            } else if (itemId == R.id.nav_list) {
                intent.putExtra("fragmentToShow", "list");
            } else if (itemId == R.id.nav_cart) {
                intent.putExtra("fragmentToShow", "cart");
            } else if (itemId == R.id.nav_profile) {
                intent.putExtra("fragmentToShow", "profile");
            } else {
                return false;
            }

            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        });

    }
}
