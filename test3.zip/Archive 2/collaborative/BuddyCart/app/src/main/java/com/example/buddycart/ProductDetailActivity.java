package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.buddycart.model.Item;
import com.example.buddycart.model.CartItem;

import com.example.buddycart.model.Store;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;


public class ProductDetailActivity extends AppCompatActivity {

    TextView itemName, itemPrice, itemDescription, quantityText;
    Button addToCartButton, increaseQty, decreaseQty;
    ImageView favoriteIcon, itemImage;
    int quantity = 1;

    Item selectedItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View contentView = getLayoutInflater().inflate(R.layout.home_4, null);
        FrameLayout container = findViewById(R.id.fragment_container);
        container.addView(contentView);

        Item passedItem = (Item) getIntent().getSerializableExtra("selectedItem");
        selectedItem = findActualItem(passedItem);

        if (selectedItem == null) {
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // View references
        itemImage = contentView.findViewById(R.id.productImage);
        itemName = contentView.findViewById(R.id.itemName);
        itemPrice = contentView.findViewById(R.id.itemPrice);
        itemDescription = contentView.findViewById(R.id.itemDescription);
        quantityText = contentView.findViewById(R.id.quantityText);
        increaseQty = contentView.findViewById(R.id.increaseQty);
        decreaseQty = contentView.findViewById(R.id.decreaseQty);
        addToCartButton = contentView.findViewById(R.id.addToCartButton);
        favoriteIcon = contentView.findViewById(R.id.favoriteIcon);

        // Set item details
        itemName.setText(selectedItem.name);
        itemPrice.setText("$" + selectedItem.price);
        itemDescription.setText(selectedItem.description);
        quantityText.setText(String.valueOf(quantity));
        updateFavoriteIcon();

        // Set image dynamically from imageUrl
        if (selectedItem.imageUrl != null && !selectedItem.imageUrl.isEmpty()) {
            int imageResId = getResources().getIdentifier(selectedItem.imageUrl, "drawable", getPackageName());
            if (imageResId != 0) {
                itemImage.setImageResource(imageResId);
            } else {
                itemImage.setImageResource(R.drawable.sample_product); // fallback
            }
        }

        // Quantity logic
        increaseQty.setOnClickListener(v -> {
            quantity++;
            quantityText.setText(String.valueOf(quantity));
        });

        decreaseQty.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                quantityText.setText(String.valueOf(quantity));
            }
        });

        // Add to cart
        addToCartButton.setOnClickListener(v -> {
            // Instantiate the database helper and retrieve current cart items.
            CartDatabaseHelper dbHelper = new CartDatabaseHelper(ProductDetailActivity.this);
            List<CartItem> currentCartItems = dbHelper.getCartItems();
            String currentStoreName = Store.currentStore.getName();

            // Create the new CartItem.
            CartItem cartItem = new CartItem(
                    selectedItem.getName(),
                    selectedItem.getPrice(),
                    quantity,
                    selectedItem.getImageUrl(),
                    currentStoreName
            );

            // If the cart is empty, add the item directly.
            if (currentCartItems.isEmpty()) {
                long result = dbHelper.addOrUpdateCartItem(cartItem);
                if (result != -1) {
                    Toast.makeText(ProductDetailActivity.this, "Item added to cart", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProductDetailActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Get the store name from the first item in the cart.
                String cartStoreName = currentCartItems.get(0).getStoreName();

                // Check if the current store matches the store of items in the cart.
                if (!cartStoreName.equalsIgnoreCase(currentStoreName)) {
                    // Show an alert dialog if items come from a different store.
                    new AlertDialog.Builder(ProductDetailActivity.this)
                            .setTitle("Different Store Selected")
                            .setMessage("Your cart already contains items from " + cartStoreName +
                                    ". Do you want to remove them and start a new cart with items from " + currentStoreName + "?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                // Clear the existing cart and add the new item.
                                dbHelper.clearCart();
                                long result = dbHelper.addOrUpdateCartItem(cartItem);
                                if (result != -1) {
                                    Toast.makeText(ProductDetailActivity.this, "Item added to cart", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(ProductDetailActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                            .show();
                } else {
                    // If the store names match, add the item normally.
                    long result = dbHelper.addOrUpdateCartItem(cartItem);
                    if (result != -1) {
                        Toast.makeText(ProductDetailActivity.this, "Item added to cart", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ProductDetailActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        // Favorite toggle
        favoriteIcon.setOnClickListener(v -> {
            if (selectedItem.isFavorite) {
                Item.unmarkFavorite(selectedItem);
            } else {
                Item.markAsFavorite(selectedItem);
            }
            updateFavoriteIcon();
            Toast.makeText(this,
                    selectedItem.isFavorite ? "Added to favorites" : "Removed from favorites",
                    Toast.LENGTH_SHORT).show();
        });

        // Back button
        ImageView backButton = contentView.findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        setupBottomNav();
    }

    private void updateFavoriteIcon() {
        if (selectedItem.isFavorite) {
            favoriteIcon.setImageResource(R.drawable.fav_clicked);
        } else {
            favoriteIcon.setImageResource(R.drawable.fav);
        }
    }

    private Item findActualItem(Item passedItem) {
        for (Item item : Item.getAllItems()) {
            if (item.equals(passedItem)) {
                return item;
            }
        }
        return passedItem;
    }


    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        bottomNav.setSelectedItemId(R.id.nav_home); // highlight current section

        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            Intent intent = new Intent(this, MainActivity.class);

            if (itemId == R.id.nav_home) {
                intent.putExtra("fragmentToShow", "home");
            } else if (itemId == R.id.nav_track) {
                intent.putExtra("fragmentToShow", "track");
            } else if (itemId == R.id.nav_list) {
                intent.putExtra("fragmentToShow", "list");
            } else if (itemId == R.id.nav_cart) {
                intent.putExtra("fragmentToShow", "cart");
            } else if (itemId == R.id.nav_profile) {
                intent.putExtra("fragmentToShow", "profile");
            } else {
                return false;
            }

            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        });

    }
}
