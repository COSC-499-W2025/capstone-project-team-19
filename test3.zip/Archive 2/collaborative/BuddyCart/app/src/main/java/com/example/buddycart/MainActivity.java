package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.buddycart.data.DataProvider;
import com.example.buddycart.model.CartItem;
import com.example.buddycart.model.Store;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNav = findViewById(R.id.bottom_navigation);

        // Always handle intent for initial fragment load
        handleFragmentSwitch();

        // Bottom navigation tab switching
        bottomNav.setOnItemSelectedListener(item -> {
            Fragment newFragment = null;

            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                newFragment = new Home();
            } else if (itemId == R.id.nav_track) {
                newFragment = new Track();
            } else if (itemId == R.id.nav_list) {
                newFragment = new MyList();
            } else if (itemId == R.id.nav_cart) {
                newFragment = new Cart();
            } else if (itemId == R.id.nav_profile) {
                newFragment = new Profile();
            }

            if (newFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, newFragment)
                        .commit();
            }

            return true;
        });

        initializeCurrentStoreFromCart();
    }

    // 🔁 Called when returning to MainActivity with new intent
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent); // 🔁 Update the intent reference
        handleFragmentSwitch();
    }

    // Show correct fragment based on passed "fragmentToShow"
    private void handleFragmentSwitch() {
        String fragmentToShow = getIntent().getStringExtra("fragmentToShow");
        Fragment selectedFragment;

        if ("track".equals(fragmentToShow)) {
            selectedFragment = new Track();
            bottomNav.setSelectedItemId(R.id.nav_track);
        } else if ("list".equals(fragmentToShow)) {
            selectedFragment = new MyList();
            bottomNav.setSelectedItemId(R.id.nav_list);
        } else if ("cart".equals(fragmentToShow)) {
            selectedFragment = new Cart();
            bottomNav.setSelectedItemId(R.id.nav_cart);
        } else if ("profile".equals(fragmentToShow)) {
            selectedFragment = new Profile();
            bottomNav.setSelectedItemId(R.id.nav_profile);
        } else {
            selectedFragment = new Home();
            bottomNav.setSelectedItemId(R.id.nav_home);
        }

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, selectedFragment)
                .commit();
    }

    private void initializeCurrentStoreFromCart() {
        CartDatabaseHelper dbHelper = new CartDatabaseHelper(this);
        List<CartItem> cartItems = dbHelper.getCartItems();

        if (!cartItems.isEmpty()) {
            // Assume all items in the cart are from the same store.
            String storeNameFromCart = cartItems.get(0).getStoreName();

            // Get all available stores
            List<Store> stores = DataProvider.getStores();
            for (Store store : stores) {
                if (store.getName().equalsIgnoreCase(storeNameFromCart)) {
                    Store.currentStore = store;
                    break;
                }
            }
        }
    }
}
