package com.example.buddycart.adapters;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import com.example.buddycart.CartDatabaseHelper;
import com.example.buddycart.R;
import com.example.buddycart.model.CartItem;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<CartItem> cartItems;
    private OnCartItemQuantityChangeListener quantityChangeListener;

    // Define an interface for quantity change callbacks
    public interface OnCartItemQuantityChangeListener {
        void onQuantityChanged();
    }

    // Updated constructor to accept the listener
    public CartAdapter(List<CartItem> cartItems, OnCartItemQuantityChangeListener listener) {
        this.cartItems = cartItems;
        this.quantityChangeListener = listener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);

        holder.itemName.setText(item.getName());
        holder.itemPrice.setText("$" + item.getPrice());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        // Increase quantity listener (remains the same)
        holder.buttonIncrease.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() + 1;
            item.setQuantity(newQuantity);
            CartDatabaseHelper dbHelper = new CartDatabaseHelper(holder.itemView.getContext());
            dbHelper.updateCartItemQuantity(item.getName(), newQuantity);
            notifyItemChanged(position);
            if (quantityChangeListener != null) {
                quantityChangeListener.onQuantityChanged();
            }
        });

        // Decrease quantity listener with removal confirmation if quantity == 1
        holder.buttonDecrease.setOnClickListener(v -> {
            if (item.getQuantity() > 1) {
                int newQuantity = item.getQuantity() - 1;
                item.setQuantity(newQuantity);
                CartDatabaseHelper dbHelper = new CartDatabaseHelper(holder.itemView.getContext());
                dbHelper.updateCartItemQuantity(item.getName(), newQuantity);
                notifyItemChanged(position);
                if (quantityChangeListener != null) {
                    quantityChangeListener.onQuantityChanged();
                }
            } else {
                // Quantity is 1, so a decrease would result in 0. Ask the user if they want to remove the item.
                new AlertDialog.Builder(holder.itemView.getContext())
                        .setMessage("Do you want to remove this item from the cart?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            // Remove the item from the database and the list.
                            CartDatabaseHelper dbHelper = new CartDatabaseHelper(holder.itemView.getContext());
                            dbHelper.removeCartItem(item.getName());
                            cartItems.remove(position);
                            notifyItemRemoved(position);
                            if (quantityChangeListener != null) {
                                quantityChangeListener.onQuantityChanged();
                            }
                        })
                        .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                        .show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemPrice, itemQuantity;
        Button buttonIncrease, buttonDecrease;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            itemPrice = itemView.findViewById(R.id.item_price);
            itemQuantity = itemView.findViewById(R.id.item_quantity);
            buttonIncrease = itemView.findViewById(R.id.button_increase);
            buttonDecrease = itemView.findViewById(R.id.button_decrease);
        }
    }
}
