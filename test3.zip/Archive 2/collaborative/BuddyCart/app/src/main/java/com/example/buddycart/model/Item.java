package com.example.buddycart.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.example.buddycart.data.DataProvider;

public class Item implements Serializable {
    public String id;
    public String name;
    public String imageUrl;
    public double price;
    public String description;
    public boolean isFavorite;


    public Item(String id, String name, String imageUrl, double price, String description) {
        this.id=id;
        this.name = name;
        this.imageUrl = imageUrl;
        this.price = price;
        this.description = description;
        this.isFavorite = false;
    }

    public String getId(){return id;}

    // Optional: Set item as favorite
    public void toggleFavorite() {
        this.isFavorite = !this.isFavorite;
    }

    // Static favorite storage (just for local testing without DB)
    private static final List<Item> allItems = new ArrayList<>(); // can be populated from DataProvider
    private static final List<Item> favoriteItems = new ArrayList<>();

    public static void addToAllItems(Item item) {
        allItems.add(item);
    }

    public static void markAsFavorite(Item item) {
        item.isFavorite = true;
        if (!favoriteItems.contains(item)) {
            favoriteItems.add(item);
        }
    }

    public static void unmarkFavorite(Item item) {
        item.isFavorite = false;
        favoriteItems.remove(item);
    }

    public static List<Item> getFavoriteItems() {
        List<Item> favorites = new ArrayList<>();
        for (Item item : DataProvider.getAllItems()) {
            if (item.isFavorite) favorites.add(item);
        }
        return favorites;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Item other = (Item) obj;
        return id.equals(other.id); // or use another unique field
    }

    @Override
    public int hashCode() {
        return id.hashCode(); // same field as used in equals
    }

    public static List<Item> getAllItems() {
        return new ArrayList<>(allItems);
    }


    public String getImageUrl() {
        return this.imageUrl;
    }

    public double getPrice() {
        return this.price;
    }

    public String getName() {
        return this.name;
    }
    public boolean isCheaperThan(Item other) {
        return this.price < other.price;
    }
}

