package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MyListDetailActivity extends AppCompatActivity {

    TextView titleText, contentText;
    ImageView backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        View contentView = getLayoutInflater().inflate(R.layout.mylist_2b, null);
        FrameLayout container = findViewById(R.id.fragment_container);
        container.removeAllViews();
        container.addView(contentView);

        titleText = contentView.findViewById(R.id.listDetailTitle);
        contentText = contentView.findViewById(R.id.listDetailContent);
        backButton = contentView.findViewById(R.id.backButton);

        String title = getIntent().getStringExtra("listTitle");
        String content = getIntent().getStringExtra("listContent");
        titleText.setText(title);
        contentText.setText(content);

        backButton.setOnClickListener(v -> finish());

        setupBottomNav();
    }


    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        bottomNav.setSelectedItemId(R.id.nav_list); // highlight current section

        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            Intent intent = new Intent(this, MainActivity.class);

            if (itemId == R.id.nav_home) {
                intent.putExtra("fragmentToShow", "home");
            } else if (itemId == R.id.nav_track) {
                intent.putExtra("fragmentToShow", "track");
            } else if (itemId == R.id.nav_list) {
                intent.putExtra("fragmentToShow", "list");
            } else if (itemId == R.id.nav_cart) {
                intent.putExtra("fragmentToShow", "cart");
            } else if (itemId == R.id.nav_profile) {
                intent.putExtra("fragmentToShow", "profile");
            } else {
                return false;
            }

            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        });

    }

}
