package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.adapters.CategoryAdapter;
import com.example.buddycart.adapters.ItemAdapter;
import com.example.buddycart.model.Store;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class StoreActivity extends AppCompatActivity {

    TextView storeNameText;
    RecyclerView categoryRecyclerView, featuredRecyclerView;
    EditText searchBar;

    CategoryAdapter categoryAdapter;
    ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View contentView = getLayoutInflater().inflate(R.layout.home_2, null);
        FrameLayout container = findViewById(R.id.fragment_container);
        container.addView(contentView);

        Store selectedStore = (Store) getIntent().getSerializableExtra("selectedStore");
        Store.currentStore=selectedStore;
        if (selectedStore == null) {
            Toast.makeText(this, "Store not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }



        // View references
        storeNameText = contentView.findViewById(R.id.storeNameText);
        categoryRecyclerView = contentView.findViewById(R.id.categoryRecyclerView);
        featuredRecyclerView = contentView.findViewById(R.id.featuredRecyclerView);
        searchBar = contentView.findViewById(R.id.searchBar);

        storeNameText.setText(selectedStore.name);

        // Set up adapters
        categoryAdapter = new CategoryAdapter(selectedStore.categories, this);
        itemAdapter = new ItemAdapter(selectedStore.offers, this, R.layout.item_product);


        // 4 columns for categories
        categoryRecyclerView.setLayoutManager(new GridLayoutManager(this, 4));
        categoryRecyclerView.setAdapter(categoryAdapter); // your adapter here

        // 3 columns for featured items
        featuredRecyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        featuredRecyclerView.setAdapter(itemAdapter); // your adapter here


        // Search functionality for both categories and featured items
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                categoryAdapter.getFilter().filter(s.toString());
                itemAdapter.getFilter().filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Back button
        ImageView backButton = contentView.findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        setupBottomNav();
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        bottomNav.setSelectedItemId(R.id.nav_home); // highlight current section

        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            Intent intent = new Intent(this, MainActivity.class);

            if (itemId == R.id.nav_home) {
                intent.putExtra("fragmentToShow", "home");
            } else if (itemId == R.id.nav_track) {
                intent.putExtra("fragmentToShow", "track");
            } else if (itemId == R.id.nav_list) {
                intent.putExtra("fragmentToShow", "list");
            } else if (itemId == R.id.nav_cart) {
                intent.putExtra("fragmentToShow", "cart");
            } else if (itemId == R.id.nav_profile) {
                intent.putExtra("fragmentToShow", "profile");
            } else {
                return false;
            }

            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        });




    }

    public String CurrentStore;
}
