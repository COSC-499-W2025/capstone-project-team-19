// MessageDriver.java
package com.example.buddycart;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class MessageDriver extends Fragment {

    private LinearLayout chatContainer;
    private EditText inputField;
    private Button sendButton;
    private Handler handler = new Handler();

    // Chat history stored statically for session-persistent memory
    private static final List<String> chatHistory = new ArrayList<>();

    public MessageDriver() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.message_driver, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        chatContainer = view.findViewById(R.id.chat_container);
        inputField = view.findViewById(R.id.input_field);
        sendButton = view.findViewById(R.id.send_button);

        // Load any previous chat history
        for (String message : chatHistory) {
            addMessage(message, false); // false = don't re-add to history
        }

        sendButton.setOnClickListener(v -> {
            String message = inputField.getText().toString().trim();
            if (!TextUtils.isEmpty(message)) {
                addMessage("You: " + message, true);
                inputField.setText("");
                simulateReply(message);
            }
        });

        ImageView backButton = view.findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new TrackItem())
                    .addToBackStack(null)
                    .commit();
        });
    }

    private void addMessage(String text, boolean addToHistory) {
        TextView msg = new TextView(getContext());
        msg.setText(text.contains("You:") ? text.replace("You: ", "") : text.replace("Driver: ", ""));
        msg.setTextSize(16);
        msg.setPadding(24, 16, 24, 16);
        msg.setTextColor(text.contains("You:") ? 0xFFFFFFFF : 0xFF000000);

        LinearLayout bubble = new LinearLayout(getContext());
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        bubble.setPadding(8, 8, 8, 8);

        if (text.startsWith("You:")) {
            bubble.setBackgroundResource(R.drawable.bubble_user); // black background
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            params.gravity = Gravity.END;
            bubble.setLayoutParams(params);
        } else {
            bubble.setBackgroundResource(R.drawable.bubble_driver); // grey background
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            params.gravity = Gravity.START;
            bubble.setLayoutParams(params);
        }

        bubble.addView(msg);
        chatContainer.addView(bubble);

        if (addToHistory) chatHistory.add(text);
    }

    private void simulateReply(String userMessage) {
        handler.postDelayed(() -> {
            String reply = "";
            if (userMessage.equalsIgnoreCase("Hey is the item missing?")) {
                reply = "yeah it is out of stock";
            } else if (userMessage.equalsIgnoreCase("okay thanks")) {
                reply = "no worries, I am checking out now";
            }

            if (!reply.isEmpty()) {
                addMessage("Driver: " + reply, true);
            }
        }, 1000);
    }

    public static MessageDriver newInstance() {
        return new MessageDriver();
    }
}


