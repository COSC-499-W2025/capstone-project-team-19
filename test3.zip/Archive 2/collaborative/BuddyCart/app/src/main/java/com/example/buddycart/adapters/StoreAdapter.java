package com.example.buddycart.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.R;
import com.example.buddycart.model.Store;

import java.util.ArrayList;
import java.util.List;

public class StoreAdapter extends RecyclerView.Adapter<StoreAdapter.StoreViewHolder> implements Filterable {

    public interface OnStoreClickListener {
        void onStoreClick(Store store);
    }

    private List<Store> storeList;
    private final List<Store> storeListFull;
    private final Context context;
    private final OnStoreClickListener listener;

    public StoreAdapter(List<Store> storeList, Context context, OnStoreClickListener listener) {
        this.storeList = storeList;
        this.context = context;
        this.listener = listener;
        this.storeListFull = new ArrayList<>(storeList); // backup for filtering
    }

    @Override
    public StoreViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_store, parent, false);
        return new StoreViewHolder(view);
    }

    @Override
    public void onBindViewHolder(StoreViewHolder holder, int position) {
        Store store = storeList.get(position);
        holder.storeName.setText(store.name);
        holder.storeDuration.setText(store.duration);

        if (store.imageUrl != null && !store.imageUrl.isEmpty()) {
            int imageResId = context.getResources().getIdentifier(store.imageUrl, "drawable", context.getPackageName());
            if (imageResId != 0) {
                holder.storeImage.setImageResource(imageResId);
            } else {
                holder.storeImage.setImageResource(R.drawable.circle); // fallback image
            }
        } else {
            holder.storeImage.setImageResource(R.drawable.circle);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onStoreClick(store);
            }
        });
    }

    @Override
    public int getItemCount() {
        return storeList.size();
    }

    @Override
    public Filter getFilter() {
        return storeFilter;
    }

    private final Filter storeFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Store> filtered = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filtered.addAll(storeListFull);
            } else {
                String pattern = constraint.toString().toLowerCase().trim();
                for (Store store : storeListFull) {
                    if (store.name.toLowerCase().contains(pattern)) {
                        filtered.add(store);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filtered;
            return results;
        }

        @Override
        @SuppressWarnings("unchecked")
        protected void publishResults(CharSequence constraint, FilterResults results) {
            storeList.clear();
            storeList.addAll((List<Store>) results.values);
            notifyDataSetChanged();
        }
    };

    public static class StoreViewHolder extends RecyclerView.ViewHolder {
        TextView storeName, storeDuration;
        ImageView storeImage;

        public StoreViewHolder(View itemView) {
            super(itemView);
            storeName = itemView.findViewById(R.id.storeNameText);
            storeDuration = itemView.findViewById(R.id.storeDurationText);
            storeImage = itemView.findViewById(R.id.storeImage);
        }
    }
}
