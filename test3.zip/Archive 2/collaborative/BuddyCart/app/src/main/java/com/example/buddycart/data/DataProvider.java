package com.example.buddycart.data;

import com.example.buddycart.model.Category;
import com.example.buddycart.model.Item;
import com.example.buddycart.model.Store;

import java.util.ArrayList;
import java.util.List;

public class DataProvider {

    public static List<Store> getStores() {
        List<Store> stores = new ArrayList<>();

        // ===================== STORE 1: Walmart ===================== //
        List<Item> walmartDrinks = new ArrayList<>();
        Item item1 = new Item("1", "Apple Juice", "@drawable/juice", 2.99, "Fresh and sweet apple juice.\nNutrition info: 120 kcal, 0g fat, 28g sugar per 250ml.");
        Item item2 = new Item("2", "Orange Soda", "@drawable/orange_soda", 1.49, "Fizzy orange delight.\nNutrition info: 140 kcal, 0g fat, 36g sugar per 355ml.");
        Item item3 = new Item("3", "Lemon Tea", "@drawable/lemon_tea", 1.99, "Cool and refreshing.\nNutrition info: 100 kcal, 0g fat, 24g sugar per 300ml.");
        Item item4 = new Item("4", "Cola", "@drawable/cola", 1.49, "Classic cola taste.\nNutrition info: 150 kcal, 0g fat, 39g sugar per 355ml.");
        Item item5 = new Item("5", "Mineral Water", "@drawable/mineral_water", 0.99, "Pure and hydrating.\nNutrition info: 0 kcal, 0g fat, 0g sugar.");
        Item item6 = new Item("6", "Grape Juice", "@drawable/grape_juice", 2.59, "Sweet and tangy.\nNutrition info: 130 kcal, 0g fat, 32g sugar per 250ml.");
        Item item7 = new Item("7", "Iced Coffee", "@drawable/iced_coffee", 2.99, "Chilled and energizing.\nNutrition info: 180 kcal, 3g fat, 24g sugar.");
        Item item8 = new Item("8", "Energy Drink", "@drawable/energy_drink", 3.49, "Boost your energy.\nNutrition info: 110 kcal, 0g fat, 27g sugar.");
        Item item9 = new Item("9", "Strawberry Milk", "@drawable/strawberry_milk", 2.29, "Creamy and fruity.\nNutrition info: 160 kcal, 5g fat, 20g sugar.");
        Item item10 = new Item("10", "Coconut Water", "@drawable/coconut_water", 2.49, "Hydrating and natural.\nNutrition info: 60 kcal, 0g fat, 14g sugar.");
        registerItems(walmartDrinks, item1, item2, item3, item4, item5, item6, item7, item8, item9, item10);

        List<Item> walmartVegetables = new ArrayList<>();
        Item item11 = new Item("11", "Carrots", "@drawable/carrot", 0.99, "Crunchy and sweet.\nNutrition info: 41 kcal, 0g fat, 5g sugar per 100g.");
        Item item12 = new Item("12", "Broccoli", "@drawable/broccoli", 1.89, "Rich in vitamins.\nNutrition info: 55 kcal, 0g fat, 2g sugar per 100g.");
        Item item13 = new Item("13", "Spinach", "@drawable/spinach", 1.89, "Green and fresh.\nNutrition info: 23 kcal, 0g fat, 0g sugar per 100g.");
        Item item14 = new Item("14", "Cucumber", "@drawable/cucumber", 0.79, "Cool and hydrating.\nNutrition info: 16 kcal, 0g fat, 2g sugar per 100g.");
        Item item15 = new Item("15", "Lettuce", "@drawable/lettuce", 1.29, "Fresh salad essential.\nNutrition info: 15 kcal, 0g fat, 1g sugar per 100g.");
        Item item16 = new Item("16", "Kale", "@drawable/kale", 1.99, "Nutritious leafy green.\nNutrition info: 49 kcal, 1g fat, 2g sugar per 100g.");
        Item item17 = new Item("17", "Tomato", "@drawable/tomato", 1.59, "Juicy and red.\nNutrition info: 18 kcal, 0g fat, 2g sugar per 100g.");
        Item item18 = new Item("18", "Bell Pepper", "@drawable/bell_pepper", 1.79, "Sweet and colorful.\nNutrition info: 20 kcal, 0g fat, 2g sugar per 100g.");
        Item item19 = new Item("19", "Zucchini", "@drawable/zucchini", 1.49, "Mild and versatile.\nNutrition info: 17 kcal, 0g fat, 2g sugar per 100g.");
        Item item20 = new Item("20", "Green Beans", "@drawable/green_beans", 1.69, "Crisp and tender.\nNutrition info: 31 kcal, 0g fat, 2g sugar per 100g.");
        registerItems(walmartVegetables, item11, item12, item13, item14, item15, item16, item17, item18, item19, item20);

        List<Item> walmartSnacks = new ArrayList<>();
        Item item21 = new Item("21", "Potato Chips", "@drawable/potato_chips", 2.99, "Crispy and salty.\nNutrition info: 160 kcal, 10g fat, 0g sugar per 28g.");
        Item item22 = new Item("22", "Nachos", "@drawable/nachos", 3.49, "Crunchy delight.\nNutrition info: 190 kcal, 9g fat, 0g sugar per 28g.");
        Item item23 = new Item("23", "Popcorn", "@drawable/popcorn", 1.99, "Buttery snack.\nNutrition info: 150 kcal, 8g fat, 0g sugar per 1 cup.");
        Item item24 = new Item("24", "Berry Granola Bar", "@drawable/granola_bar", 1.49, "Healthy bites.\nNutrition info: 110 kcal, 4g fat, 7g sugar.");
        Item item25 = new Item("25", "Pretzels", "@drawable/pretzels", 1.89, "Twisted and tasty.\nNutrition info: 110 kcal, 1g fat, 1g sugar per 28g.");
        Item item26 = new Item("26", "Chocolate Bar", "@drawable/chocolate_bar", 1.75, "Sweet treat.\nNutrition info: 210 kcal, 13g fat, 24g sugar.");
        Item item27 = new Item("27", "Cheese Crackers", "@drawable/cheese_crackers", 2.49, "Cheesy crunch.\nNutrition info: 150 kcal, 8g fat, 2g sugar per 28g.");
        Item item28 = new Item("28", "Mixed Nuts", "@drawable/mixed_nuts", 3.99, "Nutty mix.\nNutrition info: 170 kcal, 14g fat, 1g sugar per 28g.");
        Item item29 = new Item("29", "Fruit Snacks", "@drawable/fruit_snacks", 1.99, "Juicy bites.\nNutrition info: 80 kcal, 0g fat, 11g sugar per pack.");
        Item item30 = new Item("30", "Rice Cakes", "@drawable/rice_cakes", 1.79, "Light snack.\nNutrition info: 35 kcal, 0g fat, 0g sugar per cake.");
        registerItems(walmartSnacks, item21, item22, item23, item24, item25, item26, item27, item28, item29, item30);

        List<Item> walmartMeat = new ArrayList<>();
        Item item31 = new Item("31", "Chicken Breast", "@drawable/chicken_breast", 5.99, "Boneless and skinless.\nNutrition info: 165 kcal, 3.6g fat, 0g sugar per 100g.");
        Item item32 = new Item("32", "Beef Steak", "@drawable/beef_steak", 9.49, "Juicy and tender.\nNutrition info: 250 kcal, 20g fat, 0g sugar per 100g.");
        Item item33 = new Item("33", "Turkey Slices", "@drawable/turkey_slices", 4.59, "Ready to eat.\nNutrition info: 110 kcal, 3g fat, 0g sugar per 56g.");
        Item item34 = new Item("34", "Pork Chops", "@drawable/pork_chops", 6.89, "Thick and flavorful.\nNutrition info: 240 kcal, 14g fat, 0g sugar per 100g.");
        Item item35 = new Item("35", "Ground Beef", "@drawable/ground_beef", 4.99, "Perfect for burgers.\nNutrition info: 250 kcal, 20g fat, 0g sugar per 100g.");
        Item item36 = new Item("36", "Lamb Chops", "@drawable/lamb_chops", 10.99, "Rich in flavor.\nNutrition info: 294 kcal, 22g fat, 0g sugar per 100g.");
        Item item37 = new Item("37", "Sausages", "@drawable/sausages", 3.99, "Smoky taste.\nNutrition info: 290 kcal, 25g fat, 0g sugar per 100g.");
        Item item38 = new Item("38", "Bacon", "@drawable/bacon", 4.49, "Crispy and savory.\nNutrition info: 350 kcal, 30g fat, 0g sugar per 100g.");
        Item item39 = new Item("39", "Chicken Wings", "@drawable/chicken_wings", 5.49, "Perfect for game night.\nNutrition info: 290 kcal, 22g fat, 0g sugar per 100g.");
        Item item40 = new Item("40", "Salmon Fillet", "@drawable/salmon_fillet", 8.99, "Rich in Omega-3.\nNutrition info: 208 kcal, 13g fat, 0g sugar per 100g.");
        registerItems(walmartMeat, item31, item32, item33, item34, item35, item36, item37, item38, item39, item40);

        List<Category> walmartCategories = new ArrayList<>();
        walmartCategories.add(new Category("Drinks", "@drawable/drinks", walmartDrinks));
        walmartCategories.add(new Category("Vegetables", "@drawable/vegetables", walmartVegetables));
        walmartCategories.add(new Category("Snacks", "@drawable/snacks", walmartSnacks));
        walmartCategories.add(new Category("Meat", "@drawable/meat", walmartMeat));

        List<Item> walmartOffers = new ArrayList<>();
        walmartOffers.add(item1);
        walmartOffers.add(item12);
        walmartOffers.add(item26);
        walmartOffers.add(item39);

        Store walmart = new Store("Walmart", "@drawable/walmart", "15 minutes", walmartCategories, walmartOffers);
        stores.add(walmart);

        // ===================== STORE 2: IGA ===================== //
        List<Item> igaSnacks = new ArrayList<>();
        Item item41 = new Item("41", "Potato Chips", "@drawable/potato_chips", 3.25, "Crispy and salty.\nNutrition info: 160 kcal, 10g fat, 0g sugar per 28g.");
        Item item42 = new Item("42", "Chocolate Bar", "@drawable/chocolate_bar", 1.75, "Sweet treat.\nNutrition info: 210 kcal, 13g fat, 24g sugar.");
        Item item43 = new Item("43", "Apple Juice", "@drawable/apple_juice", 1.99, "Fresh and sweet apple juice.\nNutrition info: 120 kcal, 0g fat, 28g sugar per 250ml.");
        registerItems(igaSnacks, item41, item42, item43);

        List<Item> igaMeat = new ArrayList<>();
        Item item44 = new Item("44", "Chicken Breast", "@drawable/chicken_breast", 5.99, "Boneless and skinless.\nNutrition info: 165 kcal, 3.6g fat, 0g sugar per 100g.");
        Item item45 = new Item("45", "Beef Steak", "@drawable/beef_steak", 9.49, "Juicy and tender.\nNutrition info: 250 kcal, 20g fat, 0g sugar per 100g.");
        registerItems(igaMeat, item44, item45);

        List<Category> igaCategories = new ArrayList<>();
        igaCategories.add(new Category("Snacks", "@drawable/snacks", igaSnacks));
        igaCategories.add(new Category("Meat", "@drawable/meat", igaMeat));

        List<Item> igaOffers = new ArrayList<>();
        igaOffers.add(item42);
        igaOffers.add(item44);
        igaOffers.add(item43);

        Store iga = new Store("IGA", "@drawable/iga", "25 minutes", igaCategories, igaOffers);
        stores.add(iga);

        // ===================== STORE 3: NoFrills ===================== //
        List<Item> nofrillsDrinks = new ArrayList<>();
        Item item46 = new Item("46", "Orange Soda", "@drawable/orange_soda", 1.49, "Fizzy orange delight.\nNutrition info: 140 kcal, 0g fat, 36g sugar per 355ml.");
        Item item47 = new Item("47", "Grape Juice", "@drawable/grape_juice", 2.49, "Sweet and tangy.\nNutrition info: 130 kcal, 0g fat, 32g sugar per 250ml.");
        Item item48 = new Item("48", "Lemon Tea", "@drawable/lemon_tea", 1.99, "Cool and refreshing.\nNutrition info: 100 kcal, 0g fat, 24g sugar per 300ml.");
        registerItems(nofrillsDrinks, item46, item47, item48);

        List<Item> nofrillsVegetables = new ArrayList<>();
        Item item49 = new Item("49", "Spinach", "@drawable/spinach", 1.89, "Green and fresh.\nNutrition info: 23 kcal, 0g fat, 0g sugar per 100g.");
        Item item50 = new Item("50", "Cucumber", "@drawable/cucumber", 0.79, "Cool and hydrating.\nNutrition info: 16 kcal, 0g fat, 2g sugar per 100g.");
        registerItems(nofrillsVegetables, item49, item50);

        List<Category> nofrillsCategories = new ArrayList<>();
        nofrillsCategories.add(new Category("Drinks", "@drawable/drinks", nofrillsDrinks));
        nofrillsCategories.add(new Category("Vegetables", "@drawable/vegetables", nofrillsVegetables));

        Store nofrills = new Store("NoFrills", "@drawable/nofrills", "30 minutes", nofrillsCategories, new ArrayList<>());
        stores.add(nofrills);

        // ===================== STORE 4: Superstore ===================== //
        List<Item> superstoreSnacks = new ArrayList<>();
        Item item51 = new Item("51", "Granola Bar", "@drawable/granola_bar", 1.49, "Healthy bites.\nNutrition info: 110 kcal, 4g fat, 7g sugar.");
        Item item52 = new Item("52", "Fruit Snacks", "@drawable/fruit_snacks", 1.99, "Juicy bites.\nNutrition info: 80 kcal, 0g fat, 11g sugar per pack.");
        Item item53 = new Item("53", "Rice Cakes", "@drawable/rice_cakes", 1.79, "Light snack.\nNutrition info: 35 kcal, 0g fat, 0g sugar per cake.");
        registerItems(superstoreSnacks, item51, item52, item53);

        List<Item> superstoreMeat = new ArrayList<>();
        Item item54 = new Item("54", "Ground Beef", "@drawable/ground_beef", 4.99, "Perfect for burgers.\nNutrition info: 250 kcal, 20g fat, 0g sugar per 100g.");
        Item item55 = new Item("55", "Bacon", "@drawable/bacon", 4.49, "Crispy and savory.\nNutrition info: 350 kcal, 30g fat, 0g sugar per 100g.");
        registerItems(superstoreMeat, item54, item55);

        List<Category> superstoreCategories = new ArrayList<>();
        superstoreCategories.add(new Category("Snacks", "@drawable/snacks", superstoreSnacks));
        superstoreCategories.add(new Category("Meat", "@drawable/meat", superstoreMeat));

        Store superstore = new Store("Superstore", "@drawable/superstore", "42 minutes", superstoreCategories, new ArrayList<>());
        stores.add(superstore);

        Item item56 = new Item("56", "Broccoli", "@drawable/broccoli", 1.27, "Rich in vitamins.\nNutrition info: 55 kcal, 0g fat, 2g sugar per 100g.");
        Item item57 = new Item("57", "Broccoli", "@drawable/broccoli", 1.00, "Rich in vitamins.\nNutrition info: 55 kcal, 0g fat, 2g sugar per 100g.");

        Item item58 = new Item("58", "Apple Juice", "@drawable/juice", 1.00, "Fresh and sweet apple juice.\nNutrition info: 120 kcal, 0g fat, 28g sugar per 250ml.");

        registerItems(igaSnacks, item56);
        registerItems(nofrillsDrinks,item58);
        registerItems(nofrillsVegetables,item57);


        return stores;

    }

    private static void registerItems(List<Item> list, Item... items) {
        for (Item item : items) {
            list.add(item);
            Item.addToAllItems(item); // Register globally
        }
    }

    public static List<Item> getAllItems() {
        return Item.getAllItems();
    }


}
