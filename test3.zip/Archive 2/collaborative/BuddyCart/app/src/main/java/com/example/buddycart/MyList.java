package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.adapters.ItemAdapter;
import com.example.buddycart.adapters.MyListAdapter;
import com.example.buddycart.model.Item;
import com.example.buddycart.model.MyListData;
import com.example.buddycart.storage.MyListStorage;

import java.util.ArrayList;
import java.util.List;

public class MyList extends Fragment {

    private List<Item> allFavorites = new ArrayList<>();
    private List<Item> filteredFavorites = new ArrayList<>();
    private ItemAdapter itemAdapter;

    private List<MyListData> myLists = new ArrayList<>();
    private MyListAdapter myListAdapter;

    private EditText searchBar, searchLists;
    private TextView favoritesTab, listTab, createListButton;

    private RecyclerView favoriteRecyclerView, myListRecyclerView;

    public MyList() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.mylist, container, false);

        // Initialize views
        searchBar = view.findViewById(R.id.searchFavorite);
        favoritesTab = view.findViewById(R.id.tabFavorites);
        listTab = view.findViewById(R.id.tabList);
        createListButton = view.findViewById(R.id.createListButton);
        favoriteRecyclerView = view.findViewById(R.id.favoriteRecyclerView);
        myListRecyclerView = view.findViewById(R.id.myListRecyclerView);
        searchLists = view.findViewById(R.id.searchLists);

        searchLists.setVisibility(View.GONE);
        listTab.setAlpha(0.2f);

        // Set up favorite adapter
        itemAdapter = new ItemAdapter(filteredFavorites, requireContext(), R.layout.item_product);
        favoriteRecyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        favoriteRecyclerView.setAdapter(itemAdapter);

        // Set up list adapter
        myLists = MyListStorage.getLists();
        myListAdapter = new MyListAdapter(requireContext(), myLists);
        myListRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        myListRecyclerView.setAdapter(myListAdapter);

        // Favorites Tab
        favoritesTab.setOnClickListener(v -> {
            favoritesTab.setAlpha(1f);
            listTab.setAlpha(0.2f);
            favoriteRecyclerView.setVisibility(View.VISIBLE);
            searchBar.setVisibility(View.VISIBLE);
            myListRecyclerView.setVisibility(View.GONE);
            createListButton.setVisibility(View.GONE);
            searchLists.setVisibility(View.GONE);
        });

        // Lists Tab
        listTab.setOnClickListener(v -> {
            favoritesTab.setAlpha(0.2f);
            listTab.setAlpha(1f);
            favoriteRecyclerView.setVisibility(View.GONE);
            searchBar.setVisibility(View.GONE);
            searchLists.setVisibility(View.VISIBLE);
            myListRecyclerView.setVisibility(View.VISIBLE);
            createListButton.setVisibility(View.VISIBLE);
        });

        createListButton.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), MyListAddActivity.class);
            startActivity(intent);
        });

        // Search favorites
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterFavorites(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Search lists
        searchLists.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterLists(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh favorite items
        allFavorites = Item.getFavoriteItems();
        filterFavorites(searchBar.getText().toString());

        // Refresh user-created lists
        myLists.clear();
        myLists.addAll(MyListStorage.getLists());
        myListAdapter.notifyDataSetChanged();
    }

    private void filterFavorites(String keyword) {
        filteredFavorites.clear();
        if (keyword.isEmpty()) {
            filteredFavorites.addAll(allFavorites);
        } else {
            for (Item item : allFavorites) {
                if (item.name.toLowerCase().contains(keyword.toLowerCase())) {
                    filteredFavorites.add(item);
                }
            }
        }
        itemAdapter.notifyDataSetChanged();
    }

    private void filterLists(String keyword) {
        List<MyListData> filtered = new ArrayList<>();
        for (MyListData list : MyListStorage.getLists()) {
            if (list.title.toLowerCase().contains(keyword.toLowerCase())) {
                filtered.add(list);
            }
        }

        myLists.clear();
        myLists.addAll(filtered);
        myListAdapter.notifyDataSetChanged();
    }


}
