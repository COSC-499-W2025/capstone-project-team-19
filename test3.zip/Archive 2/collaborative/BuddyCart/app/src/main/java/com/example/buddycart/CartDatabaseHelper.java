package com.example.buddycart;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;
import com.example.buddycart.model.CartItem;
import java.util.ArrayList;
import java.util.List;

public class CartDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "cart.db";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_CART = "cart";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_QUANTITY = "quantity";
    private static final String COLUMN_IMAGE_URL = "image_url";
    private static final String COLUMN_STORE_NAME="storeName";


    public CartDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CART_TABLE = "CREATE TABLE " + TABLE_CART + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NAME + " TEXT, "
                + COLUMN_PRICE + " REAL, "
                + COLUMN_QUANTITY + " INTEGER, "
                + COLUMN_IMAGE_URL + " TEXT, "
                + COLUMN_STORE_NAME + " TEXT"
                + ")";
        db.execSQL(CREATE_CART_TABLE);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CART);
        onCreate(db);
    }

    // Insert a new CartItem
    public long addCartItem(CartItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, item.getName());
        values.put(COLUMN_PRICE, item.getPrice());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_IMAGE_URL, item.getImageUrl());
        values.put((COLUMN_STORE_NAME), item.getStoreName());
        long id = db.insert(TABLE_CART, null, values);
        db.close();
        return id;
    }

    // In CartDatabaseHelper.java
    public int removeCartItem(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_CART, COLUMN_NAME + "=?", new String[]{name});
        db.close();
        return rowsAffected;
    }
    public long addOrUpdateCartItem(CartItem item) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Query the table to check if the item already exists (using name as unique identifier)
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_QUANTITY + " FROM " + TABLE_CART +
                " WHERE " + COLUMN_NAME + "=?", new String[]{item.getName()});
        if (cursor.moveToFirst()) {
            // Item exists; update the quantity
            int currentQuantity = cursor.getInt(cursor.getColumnIndex(COLUMN_QUANTITY));
            int newQuantity = currentQuantity + item.getQuantity();
            ContentValues values = new ContentValues();
            values.put(COLUMN_QUANTITY, newQuantity);
            int rowsAffected = db.update(TABLE_CART, values, COLUMN_NAME + "=?", new String[]{item.getName()});
            cursor.close();
            db.close();
            return rowsAffected; // Return number of rows updated as a success indicator.
        } else {
            // Item does not exist; insert it as new.
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, item.getName());
            values.put(COLUMN_PRICE, item.getPrice());
            values.put(COLUMN_QUANTITY, item.getQuantity());
            values.put(COLUMN_IMAGE_URL, item.getImageUrl());
            values.put(COLUMN_STORE_NAME, item.getStoreName());
            long id = db.insert(TABLE_CART, null, values);

            cursor.close();
            db.close();
            return id; // Return row id of newly inserted row.
        }
    }

    // Update the quantity of an existing CartItem (using the name as a unique key for simplicity)
    public int updateCartItemQuantity(String name, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newQuantity);
        int rowsAffected = db.update(TABLE_CART, values, COLUMN_NAME + "=?", new String[]{name});
        db.close();
        return rowsAffected;
    }
    public void clearCart() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, null, null);
        db.close();
    }


    // Retrieve all CartItems
    public List<CartItem> getCartItems() {
        List<CartItem> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CART;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
                double price = cursor.getDouble(cursor.getColumnIndex(COLUMN_PRICE));
                int quantity = cursor.getInt(cursor.getColumnIndex(COLUMN_QUANTITY));
                String imageUrl = cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE_URL));
                String storeName=cursor.getString(cursor.getColumnIndex(COLUMN_STORE_NAME));
                CartItem item = new CartItem(name, price, quantity, imageUrl, storeName);
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemList;
    }
    public int updateCartItemFromComparison(CartItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PRICE, item.getPrice());
        values.put(COLUMN_STORE_NAME, item.getStoreName());
        int rowsAffected = db.update(TABLE_CART, values, COLUMN_NAME + "=?", new String[]{item.getName()});
        db.close();
        return rowsAffected;
    }

}
