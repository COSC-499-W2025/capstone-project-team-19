package com.example.buddycart;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import com.example.buddycart.adapters.CartAdapter;
import com.example.buddycart.data.DataProvider;
import com.example.buddycart.model.CartItem;
import com.example.buddycart.model.Category;
import com.example.buddycart.model.Item;
import com.example.buddycart.model.Store;

public class Cart extends Fragment {

    private RecyclerView cartRecyclerView;
    private TextView deliveryFee, subtotal;
    private Button checkoutButton;
    private CartDatabaseHelper dbHelper;

    private static final String CURRENT_STORE_NAME = (Store.currentStore != null) ? Store.currentStore.getName() : "";

    public Cart() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.cart, container, false);

        // Retrieve the store name TextView from the inflated view.
        TextView storeNameTextView = view.findViewById(R.id.store_name);
        // Set the text using Store.currentStore (or a default if it's null)
        String activeStoreName = (Store.currentStore != null) ? Store.currentStore.getName() : "No store selected";
        storeNameTextView.setText(activeStoreName);

        cartRecyclerView = view.findViewById(R.id.cartRecyclerView);
        deliveryFee = view.findViewById(R.id.delivery_fee);
        subtotal = view.findViewById(R.id.subtotal);
        checkoutButton = view.findViewById(R.id.checkoutButton);

        dbHelper = new CartDatabaseHelper(getContext());
        List<CartItem> cartItems = dbHelper.getCartItems();

        CartAdapter adapter = new CartAdapter(cartItems, () -> updateSubtotal());
        cartRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        cartRecyclerView.setAdapter(adapter);

        updateSubtotal();

        // When checking out, perform the comparison check.
        checkoutButton.setOnClickListener(v -> {

            // First check if there are any items in the cart
            if (cartItems.isEmpty()) {
                // Show a message or handle empty cart case
                Toast.makeText(getContext(), "Your cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if there are comparable items in other stores
            if (areComparableItemsFound(cartItems)) {
                // If comparable items found, show the comparison dialog
                showCompareDialog();
            } else {
                // If no comparable items found, proceed directly to checkout
                CheckoutFragment checkoutFragment = new CheckoutFragment();
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, checkoutFragment);
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });

        return view;
    }


    /**
     * Recalculate and update the displayed subtotal.
     */
    private void updateSubtotal() {
        List<CartItem> items = dbHelper.getCartItems();
        double subtotalValue = 0.0;
        for (CartItem item : items) {
            subtotalValue += item.getPrice() * item.getQuantity();
        }
        subtotal.setText("Subtotal (before tax): $" + String.format("%.2f", subtotalValue));
    }

    /**
     * Checks if there exists a store (other than the current one) that carries every item in the cart.
     * Additionally, at least one item must be available at a lower price in that store.
     * Only if such a store exists will the comparison dialog be shown.
     */
    private boolean areComparableItemsFound(List<CartItem> cartItems) {
        List<Store> stores = DataProvider.getStores();

        for (Store store : stores) {
            // Skip the current store.
            if (!store.getName().equalsIgnoreCase(CURRENT_STORE_NAME)) {
                boolean allItemsExist = true;
                boolean atLeastOneCheaper = false;

                // Check every item in the cart.
                for (CartItem cartItem : cartItems) {
                    // Use the helper method to find a matching alternative in this store.
                    Item alternativeItem = getItemByName(store, cartItem.getName());
                    if (alternativeItem == null) {
                        // If even one item doesn't exist in this store, then this store is not a valid candidate.
                        allItemsExist = false;
                        break;
                    } else {
                        // Optionally, consider the competitor offer only if it's cheaper.
                        if (alternativeItem.getPrice() < cartItem.getPrice()) {
                            atLeastOneCheaper = true;
                        }
                    }
                }

                // If every cart item was found and at least one item is cheaper, return true.
                if (allItemsExist && atLeastOneCheaper) {
                    return true;
                }
            }
        }
        return false;
    }






    /**
     * Shows an AlertDialog prompting the user to compare prices with other stores.
     * If the user confirms ("Yes"), navigate to the comparison screen.
     */
    private void showCompareDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setMessage("Some items in your cart are available at a lower price in other stores. Do you want to compare?");
        builder.setPositiveButton("Yes", (dialog, which) -> {
            Intent intent = new Intent(getContext(), ComparisonActivity.class);
            startActivity(intent);
        });
        builder.setNegativeButton("No", (dialog, which) -> {

            goToCheckout();
        });
        builder.show();
    }
    private Item getItemByName(Store store, String itemName) {
        for (Category category : store.getCategories()) {
            for (Item item : category.getItems()) {
                if (item.getName().equalsIgnoreCase(itemName)) {
                    return item;
                }
            }
        }
        return null;
    }
    private void goToCheckout() {
        CheckoutFragment checkoutFragment = new CheckoutFragment();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, checkoutFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }



}
