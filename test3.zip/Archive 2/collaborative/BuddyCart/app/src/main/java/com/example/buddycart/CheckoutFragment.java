package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.util.List;
import com.example.buddycart.model.CartItem;

public class CheckoutFragment extends Fragment {

    private TextView addressLabel, paymentMethodLabel;
    private TextView subtotalLabel, promotionLabel, deliveryFeeLabel, serviceFeeLabel, taxesLabel, totalLabel;
    private EditText deliveryInstructions;
    private Button changeAddressButton, changePaymentMethodButton, placeOrderButton;
    private CartDatabaseHelper dbHelper;

    // Fee constants
    private static final double DELIVERY_FEE = 5.00;
    private static final double SERVICE_FEE = 3.78;
    private static final double TAX_RATE = 0.05; // 5%
    private static final double PROMOTION = 0.00; // No discount
    Spinner deliveryOptionSpinner;
    String[] deliveryOptions = {
            "Drop-off at my door",
            "Hand it to me in-person"
    };
    public CheckoutFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the checkout layout (activity_checkout.xml)
        View view = inflater.inflate(R.layout.activity_checkout, container, false);
        deliveryOptionSpinner = view.findViewById(R.id.deliveryOptionSpinner);
        deliveryInstructions = view.findViewById(R.id.deliveryInstructions);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                deliveryOptions
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deliveryOptionSpinner.setAdapter(adapter);
        dbHelper = new CartDatabaseHelper(getContext());

        // Initialize views using view.findViewById()
        addressLabel = view.findViewById(R.id.addressLabel);
        paymentMethodLabel = view.findViewById(R.id.paymentMethodLabel);
        subtotalLabel = view.findViewById(R.id.subtotalLabel);
        promotionLabel = view.findViewById(R.id.promotionLabel);
        deliveryFeeLabel = view.findViewById(R.id.deliveryFeeLabel);
        serviceFeeLabel = view.findViewById(R.id.serviceFeeLabel);
        taxesLabel = view.findViewById(R.id.taxesLabel);
        totalLabel = view.findViewById(R.id.totalLabel);
        changeAddressButton = view.findViewById(R.id.changeAddressButton);
        changePaymentMethodButton = view.findViewById(R.id.changePaymentMethodButton);
        placeOrderButton = view.findViewById(R.id.placeOrderButton);
        deliveryInstructions = view.findViewById(R.id.deliveryInstructions);

        // Set default values
        addressLabel.setText("99 Sunset Drive");
        paymentMethodLabel.setText("Visa •••• 0901");

        loadPriceDetails();

        // Launch AddressActivity on Change Address click.
        changeAddressButton.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), AddressActivity.class);
            startActivityForResult(intent, 100);
        });

        // Launch PaymentActivity on Change Payment Method click.
        changePaymentMethodButton.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), PaymentActivity.class);
            startActivityForResult(intent, 101);
        });

        // Place Order logic: add order processing here.
        placeOrderButton.setOnClickListener(v -> {
    gotoTrack();
        });


        ImageView backButton = view.findViewById(R.id.backButton);
        if (backButton != null) {
            backButton.setOnClickListener(v -> {

                getActivity().getSupportFragmentManager().popBackStack();
            });
        }

        return view;
    }

    private void loadPriceDetails() {
        List<CartItem> cartItems = dbHelper.getCartItems();
        double subtotal = 0.0;
        for (CartItem item : cartItems) {
            subtotal += item.getPrice() * item.getQuantity();
        }
        double promotionAmount = PROMOTION;
        double deliveryFee = DELIVERY_FEE;
        double serviceFee = SERVICE_FEE;
        double taxedAmount = Math.max(0, subtotal - promotionAmount);
        double taxes = taxedAmount * TAX_RATE;
        double total = (subtotal - promotionAmount) + deliveryFee + serviceFee + taxes;
        if (total < 0) total = 0;

        subtotalLabel.setText(String.format("Subtotal: $%.2f", subtotal));
        promotionLabel.setText(String.format("Promotion: -$%.2f", promotionAmount));
        deliveryFeeLabel.setText(String.format("Delivery Fee: $%.2f", deliveryFee));
        serviceFeeLabel.setText(String.format("Service Fee: $%.2f", serviceFee));
        taxesLabel.setText(String.format("Taxes: $%.2f", taxes));
        totalLabel.setText(String.format("Total: $%.2f", total));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100 && resultCode == getActivity().RESULT_OK) {
            String selectedAddress = data.getStringExtra("selectedAddress");
            if (selectedAddress != null) {
                addressLabel.setText(selectedAddress);
            }
        } else if (requestCode == 101 && resultCode == getActivity().RESULT_OK) {
            String selectedPaymentMethod = data.getStringExtra("selectedPaymentMethod");
            if (selectedPaymentMethod != null) {
                paymentMethodLabel.setText(selectedPaymentMethod);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    private void gotoTrack(){
        Track trackFragment=new Track();
        FragmentTransaction transaction =getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, trackFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
