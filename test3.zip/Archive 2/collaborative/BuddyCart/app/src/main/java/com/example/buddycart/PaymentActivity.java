package com.example.buddycart;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PaymentActivity extends AppCompatActivity {

    private RadioButton radioAmex, radioVisa, radioPaypal, radioMoonpay, radioCash;
    private List<RadioButton> radioButtons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payments);

        // Handle back arrow click
        ImageView backToSettings = findViewById(R.id.backToSettings);
        backToSettings.setOnClickListener(v -> finish());

        // Handle add new card icon click
        ImageView iconAddCard = findViewById(R.id.iconAddCard);
        iconAddCard.setOnClickListener(v -> {
            Intent intent = new Intent(PaymentActivity.this, NewCardActivity.class);
            startActivity(intent);
        });

        // Setup mutually exclusive RadioButtons
        radioAmex = findViewById(R.id.radioAmex);
        radioVisa = findViewById(R.id.radioVisa);
        radioPaypal = findViewById(R.id.radioPaypal);
        radioMoonpay = findViewById(R.id.radioMoonpay);
        radioCash = findViewById(R.id.radioCash);

        radioButtons = new ArrayList<>(Arrays.asList(
                radioAmex, radioVisa, radioPaypal, radioMoonpay, radioCash
        ));

        for (RadioButton rb : radioButtons) {
            rb.setOnClickListener(v -> {
                for (RadioButton other : radioButtons) {
                    other.setChecked(false);
                }
                rb.setChecked(true);
            });
        }

        // Add dynamically saved cards using card_item.xml layout
        LinearLayout addCardRow = findViewById(R.id.addCardRow);
        LinearLayout parentLayout = (LinearLayout) addCardRow.getParent();
        int insertIndex = parentLayout.indexOfChild(addCardRow) + 1;

        SharedPreferences prefs = getSharedPreferences("buddycart_cards", MODE_PRIVATE);
        // This clears the cards (for functional use) prefs.edit().clear().apply();
        int cardCount = prefs.getInt("count", 0);
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 0; i < cardCount; i++) {
            String cardLabel = prefs.getString("card_" + i, null);
            String cardType = prefs.getString("card_type_" + i, "generic");

            if (cardLabel != null) {

                View cardView = inflater.inflate(R.layout.card_item, parentLayout, false);
                TextView label = cardView.findViewById(R.id.cardLabel);
                RadioButton radioButton = cardView.findViewById(R.id.cardRadio);
                label.setText(cardLabel);

                radioButtons.add(radioButton);
                radioButton.setOnClickListener(v -> {
                    for (RadioButton other : radioButtons) {
                        other.setChecked(false);
                    }
                    radioButton.setChecked(true);
                });

                parentLayout.addView(cardView, insertIndex++);
            }
        }
    }
}
