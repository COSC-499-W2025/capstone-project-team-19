package com.example.buddycart.model;

import com.example.buddycart.CartDatabaseHelper;

import java.io.Serializable;
import java.util.List;

public class Store implements Serializable {
    public String name;
    public String imageUrl;
    public String duration;
    public List<Category> categories;
    public List<Item> offers;
    public static Store currentStore=null;

    public Store(String name, String imageUrl, String duration, List<Category> categories, List<Item> offers) {
        this.name = name;
        this.imageUrl = imageUrl;
        this.duration = duration;
        this.categories = categories;
        this.offers = offers;
    }

    public String getName() {
        return this.name;
    }

    public List<Category> getCategories() {
        return categories;
    }
}
