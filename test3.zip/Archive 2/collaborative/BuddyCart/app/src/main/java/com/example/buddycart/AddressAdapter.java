package com.example.buddycart;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AddressAdapter extends RecyclerView.Adapter<AddressAdapter.ViewHolder> {

    private List<Address> addressList;
    private Context context;

    public AddressAdapter(Context context, List<Address> addresses) {
        this.context = context;
        this.addressList = addresses;
    }

    @Override
    public AddressAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_address_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(AddressAdapter.ViewHolder holder, int position) {
        Address address = addressList.get(position);
        holder.addressText.setText(address.getAddressText());

        holder.deleteButton.setOnClickListener(v -> {
            addressList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, addressList.size());
        });
    }

    @Override
    public int getItemCount() {
        return addressList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView addressText;
        ImageView deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            addressText = itemView.findViewById(R.id.address_text);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
