package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.buddycart.model.CartItem;
import java.util.ArrayList;
import java.util.List;

public class TrackItem extends Fragment {

    private RecyclerView recyclerView;
    private ShoppingProgressAdapter adapter;
    private List<CartItem> cartItems = new ArrayList<>();
    private Handler handler = new Handler();
    private boolean stopRepeatingDialog = false;

    public TrackItem() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.track_item, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView summaryText = view.findViewById(R.id.items_found_summary);
        recyclerView = view.findViewById(R.id.progressRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        CartDatabaseHelper dbHelper = new CartDatabaseHelper(getContext());
        cartItems = dbHelper.getCartItems();

        adapter = new ShoppingProgressAdapter(cartItems, (checkedCount, totalCount) -> {
            summaryText.setText(checkedCount + " out of " + totalCount + " items found");
        });

        recyclerView.setAdapter(adapter);

        startSimulatedProgress();

        Button btnMessage = view.findViewById(R.id.btnMessage);
        btnMessage.setOnClickListener(v -> {
            stopRepeatingDialog = true;
            handler.removeCallbacksAndMessages(null);

            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new MessageDriver())
                    .addToBackStack(null)
                    .commit();
        });
    }

    private void startSimulatedProgress() {
        long totalTime = 10000;
        int itemsToCheck = cartItems.size() - 1;

        for (int i = 0; i < itemsToCheck; i++) {
            int index = i;
            long delay = (totalTime / cartItems.size()) * (i + 1);

            handler.postDelayed(() -> {
                adapter.checkItem(index);
            }, delay);
        }

        handler.postDelayed(() -> {
            showSubstitutionDialog(cartItems.get(cartItems.size() - 1).getName());
        }, totalTime);
    }

    private void showSubstitutionDialog(String itemName) {
        new AlertDialog.Builder(requireContext())
                .setMessage("Driver could not find item " + itemName + ", would you like to proceed with the selected substitution method?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    requireActivity().getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.fragment_container, new TrackDelivery())
                            .addToBackStack(null)
                            .commit();
                })
                .setNegativeButton("No", (dialog, which) -> {
                    if (!stopRepeatingDialog) {
                        handler.postDelayed(() -> {
                            showSubstitutionDialog(itemName);
                        }, 3000);
                    }
                })
                .show();
    }

    private static class ShoppingProgressAdapter extends RecyclerView.Adapter<ShoppingProgressAdapter.ViewHolder> {
        private final List<CartItem> items;
        private final List<Boolean> isChecked;
        private final ProgressListener listener;

        public interface ProgressListener {
            void onProgressUpdate(int checkedCount, int totalCount);
        }

        public ShoppingProgressAdapter(List<CartItem> items, ProgressListener listener) {
            this.items = items;
            this.listener = listener;
            this.isChecked = new ArrayList<>();
            for (int i = 0; i < items.size(); i++) {
                isChecked.add(false);
            }
        }

        public void checkItem(int position) {
            isChecked.set(position, true);
            notifyItemChanged(position);

            if (listener != null) {
                int checked = 0;
                for (boolean b : isChecked) {
                    if (b) checked++;
                }
                listener.onProgressUpdate(checked, items.size());
            }
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_shopping_progress, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            CartItem item = items.get(position);
            holder.itemName.setText(item.getName());

            String details = "Qty: " + item.getQuantity() + "   Price: $" + String.format("%.2f", item.getPrice());
            holder.itemDetails.setText(details);

            boolean checked = isChecked.get(position);
            holder.itemCheckbox.setChecked(checked);

            if (checked) {
                AlphaAnimation animation = new AlphaAnimation(0.0f, 1.0f);
                animation.setDuration(600);
                holder.itemCheckbox.startAnimation(animation);
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            CheckBox itemCheckbox;
            TextView itemName;
            TextView itemDetails;

            ViewHolder(View itemView) {
                super(itemView);
                itemCheckbox = itemView.findViewById(R.id.item_checkbox);
                itemName = itemView.findViewById(R.id.item_name);
                itemDetails = itemView.findViewById(R.id.item_details);
                itemCheckbox.setEnabled(false);
            }
        }
    }
}


