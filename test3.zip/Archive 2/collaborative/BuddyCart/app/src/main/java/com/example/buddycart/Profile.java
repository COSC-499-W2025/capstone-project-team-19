package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;

public class Profile extends Fragment {

    public Profile() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.settings, container, false);

        // Back to Home when clicking Exit
        ImageView exitIcon = view.findViewById(R.id.exitIcon);
        exitIcon.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new Home())
                    .commit();
            ((MainActivity) requireActivity()).bottomNav.setSelectedItemId(R.id.nav_home);
        });

        // Address row -> AddressActivity
        LinearLayout addressRow = view.findViewById(R.id.addressRow);
        addressRow.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AddressActivity.class);
            startActivity(intent);
        });

        // Payment row -> PaymentActivity
        LinearLayout paymentRow = view.findViewById(R.id.paymentRow);
        paymentRow.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), PaymentActivity.class);
            startActivity(intent);
        });

        return view;
    }
}
