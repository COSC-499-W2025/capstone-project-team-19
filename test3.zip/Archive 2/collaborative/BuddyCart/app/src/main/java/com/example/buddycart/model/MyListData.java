package com.example.buddycart.model;

public class MyListData {
    public String title;
    public String content;

    public MyListData(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

}
