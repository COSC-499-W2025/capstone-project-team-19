package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.adapters.StoreAdapter;
import com.example.buddycart.data.DataProvider;
import com.example.buddycart.model.Store;

import java.util.List;

public class Home extends Fragment {

    private StoreAdapter storeAdapter;

    public Home() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home, container, false);

        EditText searchBar = view.findViewById(R.id.searchBar);
        RecyclerView storeRecyclerView = view.findViewById(R.id.storeRecyclerView);

        List<Store> storeList = DataProvider.getStores();

        // Setup RecyclerView with 4-column grid
        storeRecyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 4));

        storeAdapter = new StoreAdapter(storeList, requireContext(), store -> {
            Intent intent = new Intent(requireContext(), StoreActivity.class);
            intent.putExtra("selectedStore", store);
            startActivity(intent);
        });

        storeRecyclerView.setAdapter(storeAdapter);

        // Setup search functionality
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                storeAdapter.getFilter().filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        return view;
    }
}
