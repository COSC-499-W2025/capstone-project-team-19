package com.example.buddycart;

public class Address {
    private String addressText;

    public Address(String addressText) {
        this.addressText = addressText;
    }

    public String getAddressText() {
        return addressText;
    }
}
