package com.example.buddycart;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AddressActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AddressAdapter adapter;
    private List<Address> addressList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addresses);

        ImageView backToSettings = findViewById(R.id.backToSettings);
        backToSettings.setOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.addressRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        addressList = new ArrayList<>();
        addressList.add(new Address("775 Academy Way"));
        addressList.add(new Address("776 Cawston Avenue"));
        addressList.add(new Address("65 Chesterfield Ave"));
        addressList.add(new Address("389 Valley Road"));
        addressList.add(new Address("1337 Discovery Ave"));
        addressList.add(new Address("99 Sunset Drive"));

        adapter = new AddressAdapter(this, addressList);
        recyclerView.setAdapter(adapter);
    }
}
