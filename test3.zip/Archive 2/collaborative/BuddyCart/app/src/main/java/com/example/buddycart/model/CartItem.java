package com.example.buddycart.model;

public class CartItem {
    private String name;
    private double price;
    private int quantity;
    private String imageUrl;

    private String storeName;
    public CartItem(String name, double price, int quantity, String imageUrl, String storeName) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.imageUrl=imageUrl;
        this.storeName=storeName;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }
    public String getStoreName(){
        return this.storeName;
    }

    public void setPrice(double price){this.price=price;};
    public void setStoreName(String storeName){this.storeName=storeName;};
}

