package com.example.buddycart.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.CategoryActivity;
import com.example.buddycart.R;
import com.example.buddycart.model.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder> implements Filterable {

    private List<Category> categoryList;
    private final List<Category> categoryListFull; // for backup
    private Context context;

    public CategoryAdapter(List<Category> categoryList, Context context) {
        this.categoryList = categoryList;
        this.context = context;
        this.categoryListFull = new ArrayList<>(categoryList);
    }

    @Override
    public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CategoryViewHolder holder, int position) {
        Category category = categoryList.get(position);
        holder.categoryName.setText(category.name);

        // Load image from drawable using imageUrl
        if (category.imageUrl != null && !category.imageUrl.isEmpty()) {
            int imageResId = context.getResources().getIdentifier(
                    category.imageUrl, "drawable", context.getPackageName());
            if (imageResId != 0) {
                holder.categoryImage.setImageResource(imageResId);
            } else {
                holder.categoryImage.setImageResource(R.drawable.circle); // fallback/default
            }
        } else {
            holder.categoryImage.setImageResource(R.drawable.circle); // fallback/default
        }

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, CategoryActivity.class);
            intent.putExtra("selectedCategory", category);
            context.startActivity(intent);
        });
    }


    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    @Override
    public Filter getFilter() {
        return categoryFilter;
    }

    private final Filter categoryFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Category> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(categoryListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (Category category : categoryListFull) {
                    if (category.name.toLowerCase().contains(filterPattern)) {
                        filteredList.add(category);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            categoryList.clear();
            categoryList.addAll((List<Category>) results.values);
            notifyDataSetChanged();
        }
    };

    public static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView categoryName;
        ImageView categoryImage;

        public CategoryViewHolder(View itemView) {
            super(itemView);
            categoryName = itemView.findViewById(R.id.categoryNameText);
            categoryImage = itemView.findViewById(R.id.categoryImage);
        }
    }

}
