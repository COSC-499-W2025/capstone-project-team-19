package com.example.buddycart.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.CartDatabaseHelper;
import com.example.buddycart.ProductDetailActivity;
import com.example.buddycart.R;
import com.example.buddycart.model.CartItem;
import com.example.buddycart.model.Item;
import com.example.buddycart.model.Store;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> implements Filterable {

    private List<Item> itemList;
    private final List<Item> itemListFull;
    private final Context context;
    private final int layoutResourceId;

    public ItemAdapter(List<Item> itemList, Context context, int layoutResourceId) {
        this.itemList = itemList;
        this.context = context;
        this.layoutResourceId = layoutResourceId;
        this.itemListFull = new ArrayList<>(itemList);
    }


    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(layoutResourceId, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.name.setText(item.name);
        holder.price.setText("$" + item.price);

        // Set item image if available
        if (item.imageUrl != null && !item.imageUrl.isEmpty()) {
            int imageResId = context.getResources().getIdentifier(item.imageUrl, "drawable", context.getPackageName());
            if (imageResId != 0) {
                holder.productImage.setImageResource(imageResId);
            }
        }

        // Navigate to ProductDetailActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ProductDetailActivity.class);
            intent.putExtra("selectedItem", item);
            context.startActivity(intent);
        });

        holder.addButton.setOnClickListener(v -> {
            // Get the database helper and current cart items
            CartDatabaseHelper dbHelper = new CartDatabaseHelper(context);
            List<CartItem> currentCartItems = dbHelper.getCartItems();
            String currentStoreName = Store.currentStore.getName();

            // Create the new cart item
            CartItem cartItem = new CartItem(
                    item.getName(),
                    item.getPrice(),
                    1,
                    item.getImageUrl(),
                    currentStoreName
            );

            // If the cart is empty, simply add the item
            if (currentCartItems.isEmpty()) {
                long result = dbHelper.addOrUpdateCartItem(cartItem);
                if (result != -1) {
                    Toast.makeText(context, "Item added to cart", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Get the store name from the first item in the cart
                String cartStoreName = currentCartItems.get(0).getStoreName();
                // Check if the store of the new item is different
                if (!cartStoreName.equalsIgnoreCase(currentStoreName)) {
                    // Show an alert dialog asking to clear the cart and start a new one
                    new AlertDialog.Builder(context)
                            .setTitle("Different Store Selected")
                            .setMessage("Your cart already contains items from " + cartStoreName +
                                    ". Do you want to remove them and start a new cart with items from " + currentStoreName + "?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                dbHelper.clearCart();
                                long result = dbHelper.addOrUpdateCartItem(cartItem);
                                if (result != -1) {
                                    Toast.makeText(context, "New item added to cart", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(context, "Failed to add item", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("No", (dialog, which) -> {
                                // User cancelled the addition
                                dialog.dismiss();
                            })
                            .show();
                } else {
                    // The current cart items are from the same store, so add/update as usual.
                    long result = dbHelper.addOrUpdateCartItem(cartItem);
                    if (result != -1) {
                        Toast.makeText(context, "Item added to cart", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }



    @Override
    public int getItemCount() {
        return itemList.size();
    }

    @Override
    public Filter getFilter() {
        return itemFilter;
    }

    private final Filter itemFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Item> filtered = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filtered.addAll(itemListFull);
            } else {
                String pattern = constraint.toString().toLowerCase().trim();
                for (Item item : itemListFull) {
                    if (item.name.toLowerCase().contains(pattern)) {
                        filtered.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filtered;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            itemList.clear();
            itemList.addAll((List<Item>) results.values);
            notifyDataSetChanged();
        }
    };

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView name, price;
        ImageView productImage, addButton;

        public ItemViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemNameText);
            price = itemView.findViewById(R.id.itemPriceText);
            productImage = itemView.findViewById(R.id.productImage);
            addButton = itemView.findViewById(R.id.addButton);
        }
    }
}
