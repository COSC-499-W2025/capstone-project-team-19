package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.adapters.ItemAdapter;
import com.example.buddycart.model.Category;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class CategoryActivity extends AppCompatActivity {

    TextView categoryTitle;
    RecyclerView itemRecyclerView;
    EditText searchBar;
    ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View contentView = getLayoutInflater().inflate(R.layout.home_3, null);
        FrameLayout container = findViewById(R.id.fragment_container);
        container.addView(contentView);

        Category selectedCategory = (Category) getIntent().getSerializableExtra("selectedCategory");
        if (selectedCategory == null) {
            Toast.makeText(this, "Category not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Views
        categoryTitle = contentView.findViewById(R.id.categoryTitle);
        itemRecyclerView = contentView.findViewById(R.id.itemRecyclerView);
        searchBar = contentView.findViewById(R.id.searchBar); // Make sure this exists in home_3.xml

        categoryTitle.setText(selectedCategory.name);

        itemAdapter = new ItemAdapter(selectedCategory.items, this, R.layout.item_product_2);
        itemRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        itemRecyclerView.setAdapter(itemAdapter);

        // 🔍 Search functionality
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                itemAdapter.getFilter().filter(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // ⬅️ Back
        ImageView backButton = contentView.findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        setupBottomNav();
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        bottomNav.setSelectedItemId(R.id.nav_home); // highlight current section

        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            Intent intent = new Intent(this, MainActivity.class);

            if (itemId == R.id.nav_home) {
                intent.putExtra("fragmentToShow", "home");
            } else if (itemId == R.id.nav_track) {
                intent.putExtra("fragmentToShow", "track");
            } else if (itemId == R.id.nav_list) {
                intent.putExtra("fragmentToShow", "list");
            } else if (itemId == R.id.nav_cart) {
                intent.putExtra("fragmentToShow", "cart");
            } else if (itemId == R.id.nav_profile) {
                intent.putExtra("fragmentToShow", "profile");
            } else {
                return false;
            }

            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        });
    }
}
