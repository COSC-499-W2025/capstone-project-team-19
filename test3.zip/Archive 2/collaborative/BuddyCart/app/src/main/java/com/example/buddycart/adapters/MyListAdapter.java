package com.example.buddycart.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.buddycart.MyListDetailActivity;
import com.example.buddycart.R;
import com.example.buddycart.model.MyListData;
import com.example.buddycart.storage.MyListStorage;

import java.util.List;

public class MyListAdapter extends RecyclerView.Adapter<MyListAdapter.ViewHolder> {

    private Context context;
    private List<MyListData> listData;

    public MyListAdapter(Context context, List<MyListData> listData) {
        this.context = context;
        this.listData = listData;
    }

    @Override
    public MyListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_mylist, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyListAdapter.ViewHolder holder, int position) {
        MyListData data = listData.get(position);
        holder.listName.setText(data.title);

        // Count how many lines/items in content
        int itemCount = data.content.split("\n").length;
        holder.itemCount.setText(itemCount + " items");

        // Open detail screen
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, MyListDetailActivity.class);
            intent.putExtra("listTitle", data.title);
            intent.putExtra("listContent", data.content);
            context.startActivity(intent);
        });

        // Remove list
        holder.removeButton.setOnClickListener(v -> {
            MyListStorage.removeList(data);
            listData.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, listData.size());
            Toast.makeText(context, "List removed", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView listName, itemCount;
        ImageView removeButton;

        public ViewHolder(View itemView) {
            super(itemView);
            listName = itemView.findViewById(R.id.listName);
            itemCount = itemView.findViewById(R.id.itemCount);
            removeButton = itemView.findViewById(R.id.removeButton);
        }
    }
}
