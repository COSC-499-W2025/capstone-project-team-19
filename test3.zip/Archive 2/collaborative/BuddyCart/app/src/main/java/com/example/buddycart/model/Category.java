package com.example.buddycart.model;

import java.io.Serializable;
import java.util.List;

public class Category implements Serializable {
    public String name;
    public String imageUrl;
    public List<Item> items;

    public Category(String name, String imageUrl, List<Item> items) {
        this.name = name;
        this.imageUrl = imageUrl;
        this.items = items;
    }

    public List<Item> getItems() {
        return this.items;
    }
}
