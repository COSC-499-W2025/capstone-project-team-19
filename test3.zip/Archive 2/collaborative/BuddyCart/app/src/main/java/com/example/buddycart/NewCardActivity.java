package com.example.buddycart;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewCardActivity extends AppCompatActivity {

    private EditText inputCardNumber, inputNickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newcard);

        ImageView backToPayments = findViewById(R.id.backToPayments);
        backToPayments.setOnClickListener(v -> finish());

        inputCardNumber = findViewById(R.id.inputCardNumber);
        inputNickname = findViewById(R.id.inputNickname);

        Button addButton = findViewById(R.id.btnAddCard);
        addButton.setOnClickListener(v -> {
            String cardNumber = inputCardNumber.getText().toString().trim();
            String nickname = inputNickname.getText().toString().trim();

            if (cardNumber.length() < 4) {
                Toast.makeText(this, "Card number must be at least 4 digits", Toast.LENGTH_SHORT).show();
                return;
            }

            String last4 = cardNumber.substring(cardNumber.length() - 4);
            String formattedCard = getCardType(cardNumber) + " •••• " + last4;
            String cardType = getCardType(cardNumber);

            SharedPreferences prefs = getSharedPreferences("buddycart_cards", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            int count = prefs.getInt("count", 0);
            editor.putString("card_" + count, formattedCard);
            editor.putString("card_type_" + count, cardType); // save card type
            editor.putInt("count", count + 1);
            editor.apply();

            Intent intent = new Intent(NewCardActivity.this, PaymentActivity.class);
            startActivity(intent);
            finish();
        });
    }
    private String getCardType(String cardNumber) {
        if (cardNumber.startsWith("34") || cardNumber.startsWith("37")) {
            return "AMEX";
        } else if (cardNumber.startsWith("4")) {
            return "VISA";
        } else if (cardNumber.startsWith("5") || cardNumber.startsWith("2")) {
            return "MASTERCARD";
        }
        return "generic";
    }
}
