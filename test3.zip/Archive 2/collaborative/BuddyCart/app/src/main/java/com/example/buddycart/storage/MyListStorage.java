package com.example.buddycart.storage;

import com.example.buddycart.model.MyListData;

import java.util.ArrayList;
import java.util.List;

public class MyListStorage {
    private static final List<MyListData> lists = new ArrayList<>();

    public static void addList(MyListData list) {
        lists.add(list);
    }

    public static List<MyListData> getLists() {
        return new ArrayList<>(lists); // return a copy
    }

    public static void removeList(MyListData list) {
        lists.remove(list);
    }

    public static void clearLists() {
        lists.clear();
    }
}
