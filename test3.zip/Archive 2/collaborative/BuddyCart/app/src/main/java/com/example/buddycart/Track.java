package com.example.buddycart;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.buddycart.model.Store;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class Track extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Handler handler = new Handler();

    public Track() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.track, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView storeText = view.findViewById(R.id.store_text);
        String activeStoreName = (Store.currentStore != null) ? Store.currentStore.getName() : "Unknown Store";
        storeText.setText(activeStoreName.toUpperCase());

        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        Button messageButton = view.findViewById(R.id.btnMessage);

        messageButton.setOnClickListener(v -> {
            requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new MessageDriver())
                    .addToBackStack(null)
                    .commit();
        });

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng start = new LatLng(49.880498841812766, -119.44043970051366);
        LatLng end;

        String storeName = (Store.currentStore != null) ? Store.currentStore.getName() : "";

        switch (storeName.toLowerCase()) {
            case "walmart":
                end = new LatLng(49.89329296772238, -119.42451376277842);
                break;
            case "iga":
                end = new LatLng(49.894633445085724, -119.39760260817191);
                break;
            case "nofrills":
                end = new LatLng(49.89177800877002, -119.47464687194943);
                break;
            case "superstore":
                end = new LatLng(49.88514598291859, -119.43280267691557);
                break;
            default:
                // fallback if store name is unknown
                end = new LatLng(49.88994554884141, -119.42536894071065); // Default location
                break;
        }

        mMap.addPolyline(new PolylineOptions().add(start, end).width(5));

        LatLngBounds bounds = new LatLngBounds.Builder()
                .include(start)
                .include(end)
                .build();

        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100)); // 100 = padding
        mMap.getUiSettings().setZoomControlsEnabled(true);

        Marker movingMarker = mMap.addMarker(new MarkerOptions().position(start).title("Driver"));
        animateMarkerMovement(movingMarker, start, end, 10 * 1000); //
    }


    private void animateMarkerMovement(Marker marker, LatLng start, LatLng end, long durationMs) {
        long startTime = System.currentTimeMillis();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = System.currentTimeMillis() - startTime;
                float t = Math.min(1f, (float) elapsed / durationMs);

                double lat = start.latitude + t * (end.latitude - start.latitude);
                double lng = start.longitude + t * (end.longitude - start.longitude);
                LatLng newPos = new LatLng(lat, lng);

                marker.setPosition(newPos);

                if (t < 1f) {
                    handler.postDelayed(this, 16); // keep moving
                } else {
                    // move to TrackItem once done
                    goToTrackItemPage();
                }
            }
        });
    }

    private void goToTrackItemPage() {
        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, new TrackItem());
        transaction.addToBackStack(null); // Optional: adds to back stack
        transaction.commit();
    }

}


