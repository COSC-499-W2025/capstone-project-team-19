package com.example.buddycart;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.buddycart.data.DataProvider;
import com.example.buddycart.model.CartItem;
import com.example.buddycart.model.Category;
import com.example.buddycart.model.Item;
import com.example.buddycart.model.Store;

import java.util.List;

public class ComparisonActivity extends AppCompatActivity {

    private LinearLayout storeCardsContainer;
    private Button checkoutButton;
    private RadioGroup storeRadioGroup;
    private CartDatabaseHelper dbHelper;
    private String selectedStore = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparison);

        // Initialize views
        storeCardsContainer = findViewById(R.id.store_cards_container);
        checkoutButton = findViewById(R.id.checkout_button);
        storeRadioGroup = findViewById(R.id.store_radio_group);

        dbHelper = new CartDatabaseHelper(this);

        loadStoreData();

        checkoutButton.setOnClickListener(view -> {

            if (selectedStore.isEmpty()) {
                if (storeCardsContainer.getChildCount() > 0) {
                    TextView tv = storeCardsContainer.getChildAt(0).findViewById(R.id.card_store_name);
                    selectedStore = tv.getText().toString();
                }
            }

            // Update the current store using the selected store name.
            List<Store> stores = DataProvider.getStores();
            Store selectedStoreObj = null;
            for (Store store : stores) {
                if (store.getName().equalsIgnoreCase(selectedStore)) {
                    selectedStoreObj = store;
                    break;
                }
            }
            if (selectedStoreObj != null) {
                Store.currentStore = selectedStoreObj;

                // Update the cart with cheaper alternatives, if any.
                List<CartItem> cartItems = dbHelper.getCartItems();
                for (CartItem cartItem : cartItems) {
                    // Only update items that are not from the selected store.
                    if (!cartItem.getStoreName().equalsIgnoreCase(selectedStoreObj.getName())) {
                        Item cheaperItem = findItemInStore(selectedStoreObj, cartItem.getName());
                        if (cheaperItem != null && cheaperItem.getPrice() < cartItem.getPrice()) {
                            cartItem.setPrice(cheaperItem.getPrice());
                            cartItem.setStoreName(selectedStoreObj.getName());
                            dbHelper.updateCartItemFromComparison(cartItem);
                        }
                    }
                }
            }
            Intent intent = new Intent(ComparisonActivity.this, MainActivity.class);
            intent.putExtra("fragmentToShow", "cart");
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Dynamically loads store data from the database and DataProvider, builds a summary for each store,
     * and inflates a store card into the container.
     */
    private void loadStoreData() {
        List<CartItem> cartItems = dbHelper.getCartItems();
        List<Store> allStores = DataProvider.getStores();

        // Clear any existing store cards.
        storeCardsContainer.removeAllViews();
        // Also clear the radio group.
        storeRadioGroup.removeAllViews();

        // Iterate over all stores.
        for (Store store : allStores) {
            double storeTotal = 0.0;
            StringBuilder storeSummary = new StringBuilder();

            // Build summary and calculate subtotal.
            for (CartItem cartItem : cartItems) {
                // Add cart items that belong to this store.
                if (cartItem.getStoreName().equalsIgnoreCase(store.getName())) {
                    storeSummary.append(cartItem.getName())
                            .append(" · $")
                            .append(cartItem.getPrice())
                            .append(" x ")
                            .append(cartItem.getQuantity())
                            .append("\n");
                    storeTotal += cartItem.getPrice() * cartItem.getQuantity();
                }
            }
            // Check for cheaper alternatives from this store.
            for (CartItem cartItem : cartItems) {
                if (!cartItem.getStoreName().equalsIgnoreCase(store.getName())) {
                    Item alternativeItem = findItemInStore(store, cartItem.getName());
                    if (alternativeItem != null && alternativeItem.getPrice() < cartItem.getPrice()) {
                        storeSummary.append(alternativeItem.getName())
                                .append(" · $")
                                .append(alternativeItem.getPrice())
                                .append(" (Cheaper!)\n");
                        storeTotal += alternativeItem.getPrice();
                    }
                }
            }

            // Only add the store if there is data (subtotal > 0).
            if (storeTotal > 0) {
                // Inflate a store card layout.
                View storeCard = LayoutInflater.from(this).inflate(R.layout.store_card, storeCardsContainer, false);
                TextView tvName = storeCard.findViewById(R.id.card_store_name);
                TextView tvTime = storeCard.findViewById(R.id.card_store_time);
                TextView tvItems = storeCard.findViewById(R.id.card_store_items);
                TextView tvSubtotal = storeCard.findViewById(R.id.card_store_subtotal);

                tvName.setText(store.getName());
                //tvTime.setText(store.getDeliveryTime() + " • " + store.getImageUrl());
                tvItems.setText(storeSummary.toString());
                tvSubtotal.setText("Subtotal: $" + String.format("%.2f", storeTotal));

                // Make the store card clickable.
                storeCard.setOnClickListener(v -> {
                    selectedStore = store.getName();

                    updateRadioGroupSelection(selectedStore);
                });

                // Add this store card to the container.
                storeCardsContainer.addView(storeCard);

                // Create a radio button for this store.
                RadioButton rb = new RadioButton(this);
                rb.setText(store.getName());
                rb.setId(View.generateViewId()); // Generate a unique id.
                rb.setButtonTintList(ColorStateList.valueOf(getColor(R.color.black)));

                // If this store is the default selection (or first), mark it as checked.
                if (selectedStore.isEmpty() || selectedStore.equalsIgnoreCase(store.getName())) {
                    selectedStore = store.getName();
                    rb.setChecked(true);
                }
                // Add the radio button to the radio group.
                storeRadioGroup.addView(rb);
            }
        }

        // Set a listener on the radio group to update the selectedStore when changed.
        storeRadioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = group.findViewById(checkedId);
            if (rb != null) {
                selectedStore = rb.getText().toString();
            }
        });
    }

    // Helper method to update the radio button selection programmatically.
    private void updateRadioGroupSelection(String selectedStoreName) {
        int count = storeRadioGroup.getChildCount();
        for (int i = 0; i < count; i++) {
            RadioButton rb = (RadioButton) storeRadioGroup.getChildAt(i);
            if (rb.getText().toString().equalsIgnoreCase(selectedStoreName)) {
                rb.setChecked(true);
                break;
            }
        }
    }



    // Helper: Find an item in a store by name.
    private Item findItemInStore(Store store, String itemName) {
        for (Category category : store.getCategories()) {
            for (Item item : category.getItems()) {
                if (item.getName().equalsIgnoreCase(itemName)) {
                    return item;
                }
            }
        }
        return null;
    }
}
