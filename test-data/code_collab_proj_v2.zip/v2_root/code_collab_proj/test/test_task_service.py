"""Tests for task service layer."""

import sqlite3
import pytest
from app.models import Database
from app.task_service import TaskService


@pytest.fixture
def service():
    db = Database(":memory:")
    return TaskService(db)


class TestTaskService:
    def test_create_and_get(self, service):
        task_id = service.create_task("Test task", description="A test")
        task = service.get_task(task_id)
        assert task is not None
        assert task["title"] == "Test task"

    def test_get_nonexistent(self, service):
        assert service.get_task(999) is None

    def test_list_tasks_empty(self, service):
        assert service.list_tasks() == []

    def test_list_tasks_filter_status(self, service):
        service.create_task("Task 1")
        id2 = service.create_task("Task 2")
        service.update_task_status(id2, "done")
        done = service.list_tasks(status="done")
        assert len(done) == 1
        assert done[0]["title"] == "Task 2"

    def test_update_status(self, service):
        task_id = service.create_task("Task")
        service.update_task_status(task_id, "in_progress")
        task = service.get_task(task_id)
        assert task["status"] == "in_progress"

    def test_update_invalid_status(self, service):
        task_id = service.create_task("Task")
        with pytest.raises(ValueError):
            service.update_task_status(task_id, "invalid")

    def test_delete_task(self, service):
        task_id = service.create_task("To delete")
        assert service.delete_task(task_id) is True
        assert service.get_task(task_id) is None

    def test_delete_nonexistent(self, service):
        assert service.delete_task(999) is False

    def test_search_tasks(self, service):
        service.create_task("Fix login bug")
        service.create_task("Add feature")
        results = service.search_tasks("bug")
        assert len(results) == 1
        assert results[0]["title"] == "Fix login bug"

    def test_get_stats(self, service):
        service.create_task("Task 1")
        service.create_task("Task 2")
        id3 = service.create_task("Task 3")
        service.update_task_status(id3, "done")
        stats = service.get_task_stats()
        assert stats["todo"] == 2
        assert stats["done"] == 1
