"""Tests for data models."""

import pytest
from app.models import Task, User, Comment


class TestTask:
    def test_create_task(self):
        task = Task(title="Write tests", description="Add unit tests")
        assert task.title == "Write tests"
        assert task.status == "todo"
        assert task.priority == "medium"

    def test_create_task_with_all_fields(self):
        task = Task(
            title="Deploy",
            description="Deploy to production",
            status="in_progress",
            priority="critical",
            assigned_to="alice",
            due_date="2025-12-31",
            tags=["deployment", "urgent"],
        )
        assert task.priority == "critical"
        assert task.due_date == "2025-12-31"
        assert "deployment" in task.tags

    def test_validate_empty_title(self):
        task = Task(title="")
        with pytest.raises(ValueError, match="cannot be empty"):
            task.validate()

    def test_validate_invalid_status(self):
        task = Task(title="Test", status="invalid")
        with pytest.raises(ValueError, match="Invalid status"):
            task.validate()

    def test_validate_review_status(self):
        task = Task(title="Test", status="review")
        assert task.validate() is True

    def test_validate_invalid_priority(self):
        task = Task(title="Test", priority="urgent")
        with pytest.raises(ValueError, match="Invalid priority"):
            task.validate()

    def test_validate_critical_priority(self):
        task = Task(title="Test", priority="critical")
        assert task.validate() is True

    def test_validate_invalid_due_date(self):
        task = Task(title="Test", due_date="not-a-date")
        with pytest.raises(ValueError, match="Invalid due date"):
            task.validate()

    def test_is_overdue_no_date(self):
        task = Task(title="Test")
        assert task.is_overdue() is False

    def test_is_overdue_past_date(self):
        task = Task(title="Test", due_date="2020-01-01")
        assert task.is_overdue() is True

    def test_to_dict(self):
        task = Task(title="Test task", task_id=1, tags=["bug"])
        result = task.to_dict()
        assert result["id"] == 1
        assert result["title"] == "Test task"
        assert result["tags"] == ["bug"]
        assert "created_at" in result


class TestUser:
    def test_create_user(self):
        user = User(username="alice", email="alice@example.com")
        assert user.username == "alice"
        assert user.role == "member"

    def test_create_admin(self):
        user = User(username="admin", email="admin@example.com", role="admin")
        assert user.is_admin() is True

    def test_member_not_admin(self):
        user = User(username="alice", email="alice@example.com")
        assert user.is_admin() is False

    def test_validate_short_username(self):
        user = User(username="ab", email="ab@example.com")
        with pytest.raises(ValueError, match="at least 3 characters"):
            user.validate()

    def test_validate_invalid_email(self):
        user = User(username="alice", email="invalid")
        with pytest.raises(ValueError, match="Invalid email"):
            user.validate()

    def test_validate_invalid_role(self):
        user = User(username="alice", email="alice@example.com", role="superadmin")
        with pytest.raises(ValueError, match="Invalid role"):
            user.validate()

    def test_to_dict_includes_role(self):
        user = User(username="alice", email="alice@example.com", role="admin")
        result = user.to_dict()
        assert result["role"] == "admin"


class TestComment:
    def test_create_comment(self):
        comment = Comment(task_id=1, author="alice", content="Looks good")
        assert comment.task_id == 1
        assert comment.author == "alice"

    def test_validate_empty_content(self):
        comment = Comment(task_id=1, author="alice", content="")
        with pytest.raises(ValueError, match="cannot be empty"):
            comment.validate()

    def test_validate_no_author(self):
        comment = Comment(task_id=1, author="", content="Test")
        with pytest.raises(ValueError, match="must have an author"):
            comment.validate()

    def test_to_dict(self):
        comment = Comment(task_id=1, author="alice", content="Done", comment_id=5)
        result = comment.to_dict()
        assert result["id"] == 5
        assert result["task_id"] == 1
