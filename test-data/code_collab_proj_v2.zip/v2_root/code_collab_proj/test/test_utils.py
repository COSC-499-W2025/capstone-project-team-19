"""Tests for utility functions."""

from app.utils import format_date, days_until, paginate, sort_tasks


class TestFormatDate:
    def test_valid_date(self):
        result = format_date("2025-03-15T10:30:00")
        assert result == "Mar 15, 2025"

    def test_none_date(self):
        assert format_date(None) == "N/A"

    def test_empty_date(self):
        assert format_date("") == "N/A"


class TestDaysUntil:
    def test_none_date(self):
        assert days_until(None) is None

    def test_future_date(self):
        result = days_until("2099-12-31")
        assert result > 0


class TestPaginate:
    def test_first_page(self):
        items = list(range(25))
        result = paginate(items, page=1, per_page=10)
        assert len(result["items"]) == 10
        assert result["total"] == 25
        assert result["pages"] == 3

    def test_last_page(self):
        items = list(range(25))
        result = paginate(items, page=3, per_page=10)
        assert len(result["items"]) == 5

    def test_empty_list(self):
        result = paginate([], page=1)
        assert result["items"] == []
        assert result["total"] == 0


class TestSortTasks:
    def test_sort_by_title(self):
        tasks = [{"title": "Zebra"}, {"title": "Apple"}]
        result = sort_tasks(tasks, sort_by="title")
        assert result[0]["title"] == "Apple"

    def test_sort_reverse(self):
        tasks = [{"title": "Apple"}, {"title": "Zebra"}]
        result = sort_tasks(tasks, sort_by="title", reverse=True)
        assert result[0]["title"] == "Zebra"
