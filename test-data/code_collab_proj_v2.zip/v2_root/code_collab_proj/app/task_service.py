"""Service layer for task operations."""

from datetime import datetime


class TaskService:
    """Handles business logic for task management."""

    def __init__(self, db):
        self.db = db

    def create_task(self, title, description="", priority="medium",
                    assigned_to=None, due_date=None, tags=None):
        cursor = self.db.conn.cursor()
        tag_str = ",".join(tags) if tags else ""
        cursor.execute(
            "INSERT INTO tasks (title, description, priority, assigned_to, due_date, tags) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (title, description, priority, assigned_to, due_date, tag_str),
        )
        self.db.conn.commit()
        return cursor.lastrowid

    def get_task(self, task_id):
        cursor = self.db.conn.cursor()
        cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return dict(row)

    def list_tasks(self, status=None, assigned_to=None, priority=None):
        cursor = self.db.conn.cursor()
        query = "SELECT * FROM tasks WHERE 1=1"
        params = []
        if status:
            query += " AND status = ?"
            params.append(status)
        if assigned_to:
            query += " AND assigned_to = ?"
            params.append(assigned_to)
        if priority:
            query += " AND priority = ?"
            params.append(priority)
        query += " ORDER BY created_at DESC"
        cursor.execute(query, params)
        return [dict(row) for row in cursor.fetchall()]

    def update_task(self, task_id, **fields):
        if not fields:
            return False
        allowed = {"title", "description", "status", "priority",
                    "assigned_to", "due_date", "tags"}
        filtered = {k: v for k, v in fields.items() if k in allowed}
        if not filtered:
            return False
        filtered["updated_at"] = datetime.now().isoformat()
        set_clause = ", ".join(f"{k} = ?" for k in filtered)
        values = list(filtered.values()) + [task_id]
        cursor = self.db.conn.cursor()
        cursor.execute(
            f"UPDATE tasks SET {set_clause} WHERE id = ?", values
        )
        self.db.conn.commit()
        return cursor.rowcount > 0

    def update_task_status(self, task_id, new_status):
        valid = ["todo", "in_progress", "review", "done"]
        if new_status not in valid:
            raise ValueError(f"Invalid status: {new_status}")
        return self.update_task(task_id, status=new_status)

    def delete_task(self, task_id):
        cursor = self.db.conn.cursor()
        cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        self.db.conn.commit()
        return cursor.rowcount > 0

    def search_tasks(self, keyword):
        cursor = self.db.conn.cursor()
        cursor.execute(
            "SELECT * FROM tasks WHERE title LIKE ? OR description LIKE ?",
            (f"%{keyword}%", f"%{keyword}%"),
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_task_stats(self):
        cursor = self.db.conn.cursor()
        cursor.execute(
            "SELECT status, COUNT(*) as count FROM tasks GROUP BY status"
        )
        rows = cursor.fetchall()
        return {row["status"]: row["count"] for row in rows}
