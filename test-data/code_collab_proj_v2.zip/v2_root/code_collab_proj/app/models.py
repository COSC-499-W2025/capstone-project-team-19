"""Data models for the task management application."""

import sqlite3
from datetime import datetime


class Database:
    """Handles SQLite database connection and schema initialization."""

    def __init__(self, db_path="tasks.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self):
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'todo',
                priority TEXT DEFAULT 'medium',
                assigned_to TEXT,
                due_date TEXT,
                tags TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                role TEXT DEFAULT 'member',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                author TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
            )
        """)
        self.conn.commit()

    def close(self):
        self.conn.close()


class Task:
    """Represents a task in the system."""

    VALID_STATUSES = ["todo", "in_progress", "review", "done"]
    VALID_PRIORITIES = ["low", "medium", "high", "critical"]

    def __init__(self, title, description="", status="todo",
                 priority="medium", assigned_to=None, due_date=None,
                 tags=None, task_id=None):
        self.id = task_id
        self.title = title
        self.description = description
        self.status = status
        self.priority = priority
        self.assigned_to = assigned_to
        self.due_date = due_date
        self.tags = tags or []
        self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()

    def validate(self):
        if not self.title or not self.title.strip():
            raise ValueError("Task title cannot be empty")
        if self.status not in self.VALID_STATUSES:
            raise ValueError(f"Invalid status: {self.status}")
        if self.priority not in self.VALID_PRIORITIES:
            raise ValueError(f"Invalid priority: {self.priority}")
        if self.due_date:
            try:
                datetime.fromisoformat(self.due_date)
            except ValueError:
                raise ValueError(f"Invalid due date format: {self.due_date}")
        return True

    def is_overdue(self):
        if not self.due_date:
            return False
        return datetime.fromisoformat(self.due_date) < datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "priority": self.priority,
            "assigned_to": self.assigned_to,
            "due_date": self.due_date,
            "tags": self.tags,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


class User:
    """Represents a user in the system."""

    VALID_ROLES = ["member", "admin", "viewer"]

    def __init__(self, username, email, role="member", user_id=None):
        self.id = user_id
        self.username = username
        self.email = email
        self.role = role

    def validate(self):
        if not self.username or len(self.username) < 3:
            raise ValueError("Username must be at least 3 characters")
        if not self.email or "@" not in self.email:
            raise ValueError("Invalid email address")
        if self.role not in self.VALID_ROLES:
            raise ValueError(f"Invalid role: {self.role}")
        return True

    def is_admin(self):
        return self.role == "admin"

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "role": self.role,
        }


class Comment:
    """Represents a comment on a task."""

    def __init__(self, task_id, author, content, comment_id=None):
        self.id = comment_id
        self.task_id = task_id
        self.author = author
        self.content = content
        self.created_at = datetime.now().isoformat()

    def validate(self):
        if not self.content or not self.content.strip():
            raise ValueError("Comment content cannot be empty")
        if not self.author:
            raise ValueError("Comment must have an author")
        return True

    def to_dict(self):
        return {
            "id": self.id,
            "task_id": self.task_id,
            "author": self.author,
            "content": self.content,
            "created_at": self.created_at,
        }
