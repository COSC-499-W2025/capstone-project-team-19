"""API route handlers for the task management application."""

from flask import Flask, request, jsonify
from .models import Database
from .task_service import TaskService
from .comment_service import CommentService

app = Flask(__name__)
db = Database()
task_service = TaskService(db)
comment_service = CommentService(db)


@app.route("/tasks", methods=["GET"])
def list_tasks():
    status = request.args.get("status")
    assigned_to = request.args.get("assigned_to")
    priority = request.args.get("priority")
    tasks = task_service.list_tasks(
        status=status, assigned_to=assigned_to, priority=priority
    )
    return jsonify({"tasks": tasks, "count": len(tasks)})


@app.route("/tasks", methods=["POST"])
def create_task():
    data = request.get_json()
    if not data or "title" not in data:
        return jsonify({"error": "Title is required"}), 400
    task_id = task_service.create_task(
        title=data["title"],
        description=data.get("description", ""),
        priority=data.get("priority", "medium"),
        assigned_to=data.get("assigned_to"),
        due_date=data.get("due_date"),
        tags=data.get("tags"),
    )
    return jsonify({"id": task_id, "message": "Task created"}), 201


@app.route("/tasks/<int:task_id>", methods=["GET"])
def get_task(task_id):
    task = task_service.get_task(task_id)
    if task is None:
        return jsonify({"error": "Task not found"}), 404
    comments = comment_service.get_comments(task_id)
    task["comments"] = comments
    return jsonify(task)


@app.route("/tasks/<int:task_id>", methods=["PUT"])
def update_task(task_id):
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400
    updated = task_service.update_task(task_id, **data)
    if not updated:
        return jsonify({"error": "Task not found"}), 404
    return jsonify({"message": "Task updated"})


@app.route("/tasks/<int:task_id>/status", methods=["PUT"])
def update_status(task_id):
    data = request.get_json()
    if not data or "status" not in data:
        return jsonify({"error": "Status is required"}), 400
    try:
        updated = task_service.update_task_status(task_id, data["status"])
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    if not updated:
        return jsonify({"error": "Task not found"}), 404
    return jsonify({"message": "Status updated"})


@app.route("/tasks/<int:task_id>", methods=["DELETE"])
def delete_task(task_id):
    deleted = task_service.delete_task(task_id)
    if not deleted:
        return jsonify({"error": "Task not found"}), 404
    return jsonify({"message": "Task deleted"})


@app.route("/tasks/search", methods=["GET"])
def search_tasks():
    keyword = request.args.get("q", "")
    if not keyword:
        return jsonify({"error": "Search query is required"}), 400
    tasks = task_service.search_tasks(keyword)
    return jsonify({"tasks": tasks, "count": len(tasks)})


@app.route("/tasks/stats", methods=["GET"])
def task_stats():
    stats = task_service.get_task_stats()
    return jsonify({"stats": stats})


@app.route("/tasks/<int:task_id>/comments", methods=["GET"])
def list_comments(task_id):
    comments = comment_service.get_comments(task_id)
    return jsonify({"comments": comments})


@app.route("/tasks/<int:task_id>/comments", methods=["POST"])
def add_comment(task_id):
    data = request.get_json()
    if not data or "content" not in data or "author" not in data:
        return jsonify({"error": "Author and content are required"}), 400
    try:
        comment_id = comment_service.add_comment(
            task_id, data["author"], data["content"]
        )
    except ValueError as e:
        return jsonify({"error": str(e)}), 404
    return jsonify({"id": comment_id, "message": "Comment added"}), 201


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})
