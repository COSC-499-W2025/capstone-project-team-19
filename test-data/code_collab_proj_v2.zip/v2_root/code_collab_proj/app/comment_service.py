"""Service layer for comment operations."""

from datetime import datetime


class CommentService:
    """Handles business logic for task comments."""

    def __init__(self, db):
        self.db = db

    def add_comment(self, task_id, author, content):
        cursor = self.db.conn.cursor()
        cursor.execute(
            "SELECT id FROM tasks WHERE id = ?", (task_id,)
        )
        if cursor.fetchone() is None:
            raise ValueError(f"Task {task_id} not found")
        cursor.execute(
            "INSERT INTO comments (task_id, author, content) VALUES (?, ?, ?)",
            (task_id, author, content),
        )
        self.db.conn.commit()
        return cursor.lastrowid

    def get_comments(self, task_id):
        cursor = self.db.conn.cursor()
        cursor.execute(
            "SELECT * FROM comments WHERE task_id = ? ORDER BY created_at ASC",
            (task_id,),
        )
        return [dict(row) for row in cursor.fetchall()]

    def delete_comment(self, comment_id):
        cursor = self.db.conn.cursor()
        cursor.execute("DELETE FROM comments WHERE id = ?", (comment_id,))
        self.db.conn.commit()
        return cursor.rowcount > 0

    def count_comments(self, task_id):
        cursor = self.db.conn.cursor()
        cursor.execute(
            "SELECT COUNT(*) as count FROM comments WHERE task_id = ?",
            (task_id,),
        )
        return cursor.fetchone()["count"]
