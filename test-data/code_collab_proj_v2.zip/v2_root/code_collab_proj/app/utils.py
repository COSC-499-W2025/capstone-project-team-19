"""Utility functions for the task management application."""

from datetime import datetime, timedelta


def format_date(iso_string):
    """Format an ISO date string to a human-readable format."""
    if not iso_string:
        return "N/A"
    dt = datetime.fromisoformat(iso_string)
    return dt.strftime("%b %d, %Y")


def days_until(iso_string):
    """Calculate days until a given date."""
    if not iso_string:
        return None
    target = datetime.fromisoformat(iso_string)
    delta = target - datetime.now()
    return delta.days


def paginate(items, page=1, per_page=10):
    """Paginate a list of items."""
    start = (page - 1) * per_page
    end = start + per_page
    return {
        "items": items[start:end],
        "page": page,
        "per_page": per_page,
        "total": len(items),
        "pages": (len(items) + per_page - 1) // per_page,
    }


def sort_tasks(tasks, sort_by="created_at", reverse=False):
    """Sort tasks by a given field."""
    return sorted(tasks, key=lambda t: t.get(sort_by, ""), reverse=reverse)
