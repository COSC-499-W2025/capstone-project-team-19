# Task Manager API

A collaborative task management application built with Flask and SQLite.

## Features

- Create, read, update, and delete tasks
- Filter tasks by status, assignee, and priority
- Assign tasks to team members
- Priority levels (low, medium, high, critical)
- Due dates with overdue tracking
- Task tagging
- Comments on tasks
- Full-text search across tasks
- Task status statistics
- Pagination support

## Setup

```bash
pip install -r requirements.txt
python -m app.routes
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /tasks | List all tasks (filterable) |
| POST | /tasks | Create a new task |
| GET | /tasks/:id | Get task with comments |
| PUT | /tasks/:id | Update task fields |
| PUT | /tasks/:id/status | Update task status |
| DELETE | /tasks/:id | Delete a task |
| GET | /tasks/search?q= | Search tasks |
| GET | /tasks/stats | Get status counts |
| GET | /tasks/:id/comments | List comments |
| POST | /tasks/:id/comments | Add a comment |
| GET | /health | Health check |

## Changelog

### v2 Updates
- Added comments system
- Added task search
- Added task statistics
- Added due dates and overdue detection
- Added tag support
- Added critical priority level
- Added review status
- Added utility functions (pagination, sorting, date formatting)
- Expanded test coverage
