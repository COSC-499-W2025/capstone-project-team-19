"""
Unit conversion module supporting temperature, distance, and weight conversions.
"""


class TemperatureConverter:
    """Convert between Celsius, Fahrenheit, and Kelvin."""

    @staticmethod
    def celsius_to_fahrenheit(celsius: float) -> float:
        return (celsius * 9 / 5) + 32

    @staticmethod
    def fahrenheit_to_celsius(fahrenheit: float) -> float:
        return (fahrenheit - 32) * 5 / 9

    @staticmethod
    def celsius_to_kelvin(celsius: float) -> float:
        if celsius < -273.15:
            raise ValueError("Temperature below absolute zero")
        return celsius + 273.15

    @staticmethod
    def kelvin_to_celsius(kelvin: float) -> float:
        if kelvin < 0:
            raise ValueError("Kelvin cannot be negative")
        return kelvin - 273.15


class DistanceConverter:
    """Convert between metric and imperial distance units."""

    CONVERSIONS = {
        "km_to_miles": 0.621371,
        "miles_to_km": 1.60934,
        "m_to_feet": 3.28084,
        "feet_to_m": 0.3048,
        "cm_to_inches": 0.393701,
        "inches_to_cm": 2.54,
    }

    @classmethod
    def convert(cls, value: float, conversion: str) -> float:
        if conversion not in cls.CONVERSIONS:
            raise ValueError(f"Unknown conversion: {conversion}")
        if value < 0:
            raise ValueError("Distance cannot be negative")
        return value * cls.CONVERSIONS[conversion]


class WeightConverter:
    """Convert between metric and imperial weight units."""

    @staticmethod
    def kg_to_lbs(kg: float) -> float:
        if kg < 0:
            raise ValueError("Weight cannot be negative")
        return kg * 2.20462

    @staticmethod
    def lbs_to_kg(lbs: float) -> float:
        if lbs < 0:
            raise ValueError("Weight cannot be negative")
        return lbs * 0.453592

    @staticmethod
    def grams_to_ounces(grams: float) -> float:
        return grams * 0.035274

    @staticmethod
    def ounces_to_grams(ounces: float) -> float:
        return ounces * 28.3495
