"""
A scientific calculator module with extended math operations.
"""

import math
from typing import List, Optional


class Calculator:
    """Scientific calculator with history tracking."""

    def __init__(self):
        self.history: List[str] = []
        self._last_result: Optional[float] = None

    @property
    def last_result(self) -> Optional[float]:
        return self._last_result

    def _record(self, expression: str, result: float) -> float:
        self.history.append(f"{expression} = {result}")
        self._last_result = result
        return result

    def add(self, a: float, b: float) -> float:
        return self._record(f"{a} + {b}", a + b)

    def subtract(self, a: float, b: float) -> float:
        return self._record(f"{a} - {b}", a - b)

    def multiply(self, a: float, b: float) -> float:
        return self._record(f"{a} * {b}", a * b)

    def divide(self, a: float, b: float) -> float:
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return self._record(f"{a} / {b}", a / b)

    def power(self, base: float, exponent: float) -> float:
        return self._record(f"{base} ^ {exponent}", base ** exponent)

    def sqrt(self, value: float) -> float:
        if value < 0:
            raise ValueError("Cannot compute square root of negative number")
        return self._record(f"sqrt({value})", math.sqrt(value))

    def factorial(self, n: int) -> int:
        if n < 0:
            raise ValueError("Factorial not defined for negative numbers")
        result = math.factorial(n)
        self._record(f"{n}!", result)
        return result

    def log(self, value: float, base: float = 10) -> float:
        if value <= 0:
            raise ValueError("Logarithm not defined for non-positive numbers")
        result = math.log(value, base)
        return self._record(f"log_{base}({value})", result)

    def sin(self, angle_degrees: float) -> float:
        radians = math.radians(angle_degrees)
        return self._record(f"sin({angle_degrees}deg)", math.sin(radians))

    def cos(self, angle_degrees: float) -> float:
        radians = math.radians(angle_degrees)
        return self._record(f"cos({angle_degrees}deg)", math.cos(radians))

    def clear_history(self):
        self.history.clear()
        self._last_result = None

    def get_history(self) -> List[str]:
        return list(self.history)
