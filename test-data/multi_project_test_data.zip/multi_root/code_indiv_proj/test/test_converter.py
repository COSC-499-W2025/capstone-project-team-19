"""Tests for the unit converter module."""

import pytest
from src.converter import TemperatureConverter, DistanceConverter, WeightConverter


class TestTemperature:
    def test_celsius_to_fahrenheit(self):
        assert TemperatureConverter.celsius_to_fahrenheit(0) == 32
        assert TemperatureConverter.celsius_to_fahrenheit(100) == 212

    def test_fahrenheit_to_celsius(self):
        assert TemperatureConverter.fahrenheit_to_celsius(32) == 0
        assert round(TemperatureConverter.fahrenheit_to_celsius(212), 1) == 100.0

    def test_celsius_to_kelvin(self):
        assert TemperatureConverter.celsius_to_kelvin(0) == 273.15

    def test_kelvin_below_absolute_zero(self):
        with pytest.raises(ValueError):
            TemperatureConverter.celsius_to_kelvin(-300)

    def test_kelvin_to_celsius(self):
        assert TemperatureConverter.kelvin_to_celsius(273.15) == 0


class TestDistance:
    def test_km_to_miles(self):
        result = DistanceConverter.convert(10, "km_to_miles")
        assert round(result, 2) == 6.21

    def test_miles_to_km(self):
        result = DistanceConverter.convert(5, "miles_to_km")
        assert round(result, 2) == 8.05

    def test_unknown_conversion(self):
        with pytest.raises(ValueError, match="Unknown conversion"):
            DistanceConverter.convert(1, "parsecs_to_km")

    def test_negative_distance(self):
        with pytest.raises(ValueError, match="Distance cannot be negative"):
            DistanceConverter.convert(-5, "km_to_miles")


class TestWeight:
    def test_kg_to_lbs(self):
        assert round(WeightConverter.kg_to_lbs(1), 2) == 2.20

    def test_lbs_to_kg(self):
        assert round(WeightConverter.lbs_to_kg(10), 2) == 4.54

    def test_negative_weight(self):
        with pytest.raises(ValueError):
            WeightConverter.kg_to_lbs(-1)
