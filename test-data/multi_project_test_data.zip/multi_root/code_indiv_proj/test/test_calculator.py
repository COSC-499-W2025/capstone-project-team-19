"""Tests for the calculator module."""

import pytest
from src.calculator import Calculator


@pytest.fixture
def calc():
    return Calculator()


def test_add(calc):
    assert calc.add(2, 3) == 5

def test_subtract(calc):
    assert calc.subtract(10, 4) == 6

def test_multiply(calc):
    assert calc.multiply(3, 7) == 21

def test_divide(calc):
    assert calc.divide(10, 2) == 5.0

def test_divide_by_zero(calc):
    with pytest.raises(ValueError, match="Cannot divide by zero"):
        calc.divide(5, 0)

def test_power(calc):
    assert calc.power(2, 3) == 8

def test_sqrt(calc):
    assert calc.sqrt(16) == 4.0

def test_sqrt_negative(calc):
    with pytest.raises(ValueError):
        calc.sqrt(-1)

def test_factorial(calc):
    assert calc.factorial(5) == 120

def test_factorial_zero(calc):
    assert calc.factorial(0) == 1

def test_log_base_10(calc):
    assert round(calc.log(100), 2) == 2.0

def test_sin_90(calc):
    assert round(calc.sin(90), 4) == 1.0

def test_cos_0(calc):
    assert round(calc.cos(0), 4) == 1.0

def test_history_tracking(calc):
    calc.add(1, 2)
    calc.multiply(3, 4)
    history = calc.get_history()
    assert len(history) == 2
    assert "1 + 2 = 3" in history[0]

def test_clear_history(calc):
    calc.add(1, 1)
    calc.clear_history()
    assert calc.get_history() == []
    assert calc.last_result is None

def test_last_result(calc):
    calc.add(5, 5)
    assert calc.last_result == 10
