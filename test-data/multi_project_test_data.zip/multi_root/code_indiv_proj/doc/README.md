# Scientific Calculator & Unit Converter

A Python library providing scientific calculator operations and unit conversions.

## Features

- Basic arithmetic (add, subtract, multiply, divide)
- Scientific operations (power, sqrt, factorial, log, sin, cos)
- History tracking for all operations
- Temperature conversion (Celsius, Fahrenheit, Kelvin)
- Distance conversion (km/miles, m/feet, cm/inches)
- Weight conversion (kg/lbs, grams/ounces)

## Usage

```python
from src.calculator import Calculator

calc = Calculator()
calc.add(2, 3)        # 5
calc.sqrt(16)         # 4.0
calc.get_history()    # ['2 + 3 = 5', 'sqrt(16) = 4.0']
```

## Running Tests

```bash
pytest test/ -v
```
