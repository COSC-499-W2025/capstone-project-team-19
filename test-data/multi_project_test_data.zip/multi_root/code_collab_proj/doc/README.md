# Inventory Management System

A Flask-based REST API for managing product inventory, suppliers, and purchase orders.

## Team Members

- Alice Chen - Backend API routes and database schema
- Bob Kumar - Inventory service layer and business logic
- Carol Zhang - Testing and documentation

## Features

- Product CRUD with SKU-based lookup
- Stock level tracking with low-stock alerts
- Product search across name, SKU, and category
- Total inventory value calculation
- Supplier and order management

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /products | List all products |
| POST | /products | Add a new product |
| GET | /products/:sku | Get product by SKU |
| PATCH | /products/:sku/stock | Update stock level |
| GET | /products/low-stock | Get low-stock alerts |
| GET | /products/search?q= | Search products |
| GET | /inventory/value | Get total inventory value |

## Setup

```bash
pip install -r requirements.txt
flask run
```
