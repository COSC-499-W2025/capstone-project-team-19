"""Tests for inventory service."""

import pytest
from app.models import Database, Product
from app.inventory_service import InventoryService


@pytest.fixture
def service():
    db = Database(":memory:")
    return InventoryService(db)


def test_add_and_retrieve_product(service):
    product = Product("Laptop", "LAP-001", "Electronics", 999.99, quantity=50)
    service.add_product(product)
    result = service.get_product_by_sku("LAP-001")
    assert result is not None
    assert result["name"] == "Laptop"
    assert result["price"] == 999.99


def test_update_stock_increase(service):
    service.add_product(Product("Mouse", "MOU-001", "Electronics", 29.99, quantity=10))
    new_qty = service.update_stock("MOU-001", 5)
    assert new_qty == 15


def test_update_stock_decrease(service):
    service.add_product(Product("Keyboard", "KEY-001", "Electronics", 49.99, quantity=20))
    new_qty = service.update_stock("KEY-001", -5)
    assert new_qty == 15


def test_update_stock_insufficient(service):
    service.add_product(Product("Cable", "CAB-001", "Accessories", 9.99, quantity=3))
    with pytest.raises(ValueError, match="Insufficient stock"):
        service.update_stock("CAB-001", -10)


def test_low_stock_detection(service):
    service.add_product(Product("Widget", "WID-001", "Parts", 5.99, quantity=5, reorder_level=10))
    service.add_product(Product("Gadget", "GAD-001", "Parts", 15.99, quantity=50, reorder_level=10))
    low = service.get_low_stock_products()
    assert len(low) == 1
    assert low[0]["sku"] == "WID-001"


def test_search_products(service):
    service.add_product(Product("Blue Widget", "BW-001", "Parts", 5.99))
    service.add_product(Product("Red Gadget", "RG-001", "Parts", 8.99))
    results = service.search_products("Widget")
    assert len(results) == 1
    assert results[0]["name"] == "Blue Widget"


def test_inventory_value(service):
    service.add_product(Product("Item A", "A-001", "General", 10.00, quantity=5))
    service.add_product(Product("Item B", "B-001", "General", 20.00, quantity=3))
    value = service.get_inventory_value()
    assert value == 110.0


def test_list_by_category(service):
    service.add_product(Product("Phone", "PH-001", "Electronics", 599.99))
    service.add_product(Product("Pen", "PEN-001", "Office", 2.99))
    electronics = service.list_products(category="Electronics")
    assert len(electronics) == 1
    assert electronics[0]["category"] == "Electronics"
