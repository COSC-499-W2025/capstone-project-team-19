"""
Service layer for inventory operations.
"""

from datetime import datetime


class InventoryService:
    def __init__(self, db):
        self.conn = db.conn

    def add_product(self, product):
        product.validate()
        self.conn.execute(
            """INSERT INTO products (name, sku, category, price, quantity, reorder_level)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (product.name, product.sku, product.category,
             product.price, product.quantity, product.reorder_level),
        )
        self.conn.commit()

    def get_product_by_sku(self, sku):
        row = self.conn.execute(
            "SELECT * FROM products WHERE sku = ?", (sku,)
        ).fetchone()
        return dict(row) if row else None

    def update_stock(self, sku, quantity_change):
        product = self.get_product_by_sku(sku)
        if not product:
            raise ValueError(f"Product not found: {sku}")
        new_qty = product["quantity"] + quantity_change
        if new_qty < 0:
            raise ValueError("Insufficient stock")
        self.conn.execute(
            "UPDATE products SET quantity = ?, updated_at = ? WHERE sku = ?",
            (new_qty, datetime.now().isoformat(), sku),
        )
        self.conn.commit()
        return new_qty

    def get_low_stock_products(self):
        rows = self.conn.execute(
            "SELECT * FROM products WHERE quantity <= reorder_level"
        ).fetchall()
        return [dict(r) for r in rows]

    def search_products(self, query):
        rows = self.conn.execute(
            "SELECT * FROM products WHERE name LIKE ? OR sku LIKE ? OR category LIKE ?",
            (f"%{query}%", f"%{query}%", f"%{query}%"),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_inventory_value(self):
        row = self.conn.execute(
            "SELECT SUM(price * quantity) as total_value FROM products"
        ).fetchone()
        return row["total_value"] or 0.0

    def list_products(self, category=None):
        if category:
            rows = self.conn.execute(
                "SELECT * FROM products WHERE category = ? ORDER BY name",
                (category,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM products ORDER BY name"
            ).fetchall()
        return [dict(r) for r in rows]
