"""
Flask routes for inventory management API.
"""

from flask import Flask, jsonify, request
from .models import Database, Product
from .inventory_service import InventoryService


app = Flask(__name__)
db = Database()
service = InventoryService(db)


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/products", methods=["GET"])
def list_products():
    category = request.args.get("category")
    products = service.list_products(category=category)
    return jsonify({"products": products})


@app.route("/products", methods=["POST"])
def add_product():
    data = request.get_json()
    product = Product(
        name=data["name"],
        sku=data["sku"],
        category=data["category"],
        price=data["price"],
        quantity=data.get("quantity", 0),
        reorder_level=data.get("reorder_level", 10),
    )
    service.add_product(product)
    return jsonify({"message": "Product added", "product": product.to_dict()}), 201


@app.route("/products/<sku>", methods=["GET"])
def get_product(sku):
    product = service.get_product_by_sku(sku)
    if not product:
        return jsonify({"error": "Product not found"}), 404
    return jsonify(product)


@app.route("/products/<sku>/stock", methods=["PATCH"])
def update_stock(sku):
    data = request.get_json()
    change = data.get("quantity_change", 0)
    new_qty = service.update_stock(sku, change)
    return jsonify({"sku": sku, "new_quantity": new_qty})


@app.route("/products/low-stock", methods=["GET"])
def low_stock():
    products = service.get_low_stock_products()
    return jsonify({"low_stock_products": products, "count": len(products)})


@app.route("/products/search", methods=["GET"])
def search():
    query = request.args.get("q", "")
    products = service.search_products(query)
    return jsonify({"results": products, "count": len(products)})


@app.route("/inventory/value", methods=["GET"])
def inventory_value():
    value = service.get_inventory_value()
    return jsonify({"total_inventory_value": value})
