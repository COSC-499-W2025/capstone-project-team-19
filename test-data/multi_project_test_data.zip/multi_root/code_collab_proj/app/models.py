"""
Data models for the inventory management system.
"""

import sqlite3
from datetime import datetime


class Database:
    def __init__(self, db_path=":memory:"):
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                sku TEXT UNIQUE NOT NULL,
                category TEXT NOT NULL,
                price REAL NOT NULL CHECK(price >= 0),
                quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
                reorder_level INTEGER NOT NULL DEFAULT 10,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS suppliers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                address TEXT
            );

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                supplier_id INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                total_cost REAL NOT NULL DEFAULT 0,
                ordered_at TEXT DEFAULT CURRENT_TIMESTAMP,
                received_at TEXT,
                FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
            );

            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity > 0),
                unit_cost REAL NOT NULL CHECK(unit_cost >= 0),
                FOREIGN KEY (order_id) REFERENCES orders(id),
                FOREIGN KEY (product_id) REFERENCES products(id)
            );
        """)
        self.conn.commit()


class Product:
    def __init__(self, name, sku, category, price, quantity=0, reorder_level=10):
        self.name = name
        self.sku = sku
        self.category = category
        self.price = price
        self.quantity = quantity
        self.reorder_level = reorder_level
        self.validate()

    def validate(self):
        if not self.name or not self.name.strip():
            raise ValueError("Product name is required")
        if not self.sku or not self.sku.strip():
            raise ValueError("SKU is required")
        if self.price < 0:
            raise ValueError("Price cannot be negative")
        if self.quantity < 0:
            raise ValueError("Quantity cannot be negative")

    def is_low_stock(self):
        return self.quantity <= self.reorder_level

    def to_dict(self):
        return {
            "name": self.name,
            "sku": self.sku,
            "category": self.category,
            "price": self.price,
            "quantity": self.quantity,
            "reorder_level": self.reorder_level,
        }


class Supplier:
    def __init__(self, name, email=None, phone=None, address=None):
        self.name = name
        self.email = email
        self.phone = phone
        self.address = address

    def validate(self):
        if not self.name or not self.name.strip():
            raise ValueError("Supplier name is required")
