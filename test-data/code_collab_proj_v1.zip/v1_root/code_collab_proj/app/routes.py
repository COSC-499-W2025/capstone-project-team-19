"""API route handlers for the task management application."""

from flask import Flask, request, jsonify
from .models import Database
from .task_service import TaskService

app = Flask(__name__)
db = Database()
task_service = TaskService(db)


@app.route("/tasks", methods=["GET"])
def list_tasks():
    status = request.args.get("status")
    tasks = task_service.list_tasks(status=status)
    return jsonify({"tasks": tasks})


@app.route("/tasks", methods=["POST"])
def create_task():
    data = request.get_json()
    if not data or "title" not in data:
        return jsonify({"error": "Title is required"}), 400
    task_id = task_service.create_task(
        title=data["title"],
        description=data.get("description", ""),
        priority=data.get("priority", "medium"),
        assigned_to=data.get("assigned_to"),
    )
    return jsonify({"id": task_id, "message": "Task created"}), 201


@app.route("/tasks/<int:task_id>", methods=["GET"])
def get_task(task_id):
    task = task_service.get_task(task_id)
    if task is None:
        return jsonify({"error": "Task not found"}), 404
    return jsonify(task)


@app.route("/tasks/<int:task_id>/status", methods=["PUT"])
def update_status(task_id):
    data = request.get_json()
    if not data or "status" not in data:
        return jsonify({"error": "Status is required"}), 400
    try:
        updated = task_service.update_task_status(task_id, data["status"])
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    if not updated:
        return jsonify({"error": "Task not found"}), 404
    return jsonify({"message": "Status updated"})


@app.route("/tasks/<int:task_id>", methods=["DELETE"])
def delete_task(task_id):
    deleted = task_service.delete_task(task_id)
    if not deleted:
        return jsonify({"error": "Task not found"}), 404
    return jsonify({"message": "Task deleted"})


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})
