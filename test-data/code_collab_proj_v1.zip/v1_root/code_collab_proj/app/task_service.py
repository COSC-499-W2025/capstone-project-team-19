"""Service layer for task operations."""

from datetime import datetime


class TaskService:
    """Handles business logic for task management."""

    def __init__(self, db):
        self.db = db

    def create_task(self, title, description="", priority="medium", assigned_to=None):
        cursor = self.db.conn.cursor()
        cursor.execute(
            "INSERT INTO tasks (title, description, priority, assigned_to) VALUES (?, ?, ?, ?)",
            (title, description, priority, assigned_to),
        )
        self.db.conn.commit()
        return cursor.lastrowid

    def get_task(self, task_id):
        cursor = self.db.conn.cursor()
        cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return dict(row)

    def list_tasks(self, status=None):
        cursor = self.db.conn.cursor()
        if status:
            cursor.execute("SELECT * FROM tasks WHERE status = ?", (status,))
        else:
            cursor.execute("SELECT * FROM tasks")
        return [dict(row) for row in cursor.fetchall()]

    def update_task_status(self, task_id, new_status):
        valid = ["todo", "in_progress", "done"]
        if new_status not in valid:
            raise ValueError(f"Invalid status: {new_status}")
        cursor = self.db.conn.cursor()
        cursor.execute(
            "UPDATE tasks SET status = ?, updated_at = ? WHERE id = ?",
            (new_status, datetime.now().isoformat(), task_id),
        )
        self.db.conn.commit()
        return cursor.rowcount > 0

    def delete_task(self, task_id):
        cursor = self.db.conn.cursor()
        cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        self.db.conn.commit()
        return cursor.rowcount > 0
