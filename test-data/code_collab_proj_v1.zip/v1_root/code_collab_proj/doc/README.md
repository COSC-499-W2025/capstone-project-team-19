# Task Manager API

A collaborative task management application built with Flask and SQLite.

## Features

- Create, read, update, and delete tasks
- Filter tasks by status
- Assign tasks to team members
- Priority levels (low, medium, high)

## Setup

```bash
pip install flask
python -m app.routes
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /tasks | List all tasks |
| POST | /tasks | Create a new task |
| GET | /tasks/:id | Get a specific task |
| PUT | /tasks/:id/status | Update task status |
| DELETE | /tasks/:id | Delete a task |
| GET | /health | Health check |
