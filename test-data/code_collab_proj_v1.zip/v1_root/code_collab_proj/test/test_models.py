"""Tests for data models."""

import pytest
from app.models import Task, User


class TestTask:
    def test_create_task(self):
        task = Task(title="Write tests", description="Add unit tests")
        assert task.title == "Write tests"
        assert task.status == "todo"
        assert task.priority == "medium"

    def test_validate_empty_title(self):
        task = Task(title="")
        with pytest.raises(ValueError, match="cannot be empty"):
            task.validate()

    def test_validate_invalid_status(self):
        task = Task(title="Test", status="invalid")
        with pytest.raises(ValueError, match="Invalid status"):
            task.validate()

    def test_validate_invalid_priority(self):
        task = Task(title="Test", priority="urgent")
        with pytest.raises(ValueError, match="Invalid priority"):
            task.validate()

    def test_to_dict(self):
        task = Task(title="Test task", task_id=1)
        result = task.to_dict()
        assert result["id"] == 1
        assert result["title"] == "Test task"
        assert "created_at" in result


class TestUser:
    def test_create_user(self):
        user = User(username="alice", email="alice@example.com")
        assert user.username == "alice"
        assert user.email == "alice@example.com"

    def test_validate_short_username(self):
        user = User(username="ab", email="ab@example.com")
        with pytest.raises(ValueError, match="at least 3 characters"):
            user.validate()

    def test_validate_invalid_email(self):
        user = User(username="alice", email="invalid")
        with pytest.raises(ValueError, match="Invalid email"):
            user.validate()
